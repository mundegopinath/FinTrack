// src/utils/notifications.ts
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export const requestNotificationPermissions = async (): Promise<boolean> => {
  if (!Device.isDevice) return false;

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') return false;

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('budget-alerts', {
      name: 'Budget Alerts',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#6c63ff',
    });

    await Notifications.setNotificationChannelAsync('reminders', {
      name: 'Daily Reminders',
      importance: Notifications.AndroidImportance.DEFAULT,
    });
  }

  return true;
};

export const scheduleDailyReminder = async (hour = 21, minute = 0) => {
  await Notifications.cancelAllScheduledNotificationsAsync();

  await Notifications.scheduleNotificationAsync({
    content: {
      title: '💰 Track your expenses',
      body: 'Don\'t forget to log today\'s transactions in FinTrack!',
      data: { type: 'reminder' },
    },
    trigger: {
      hour,
      minute,
      repeats: true,
      channelId: 'reminders',
    } as any,
  });
};

export const sendBudgetAlert = async (category: string, pct: number) => {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: `⚠️ Budget Alert: ${category}`,
      body: `You've used ${Math.round(pct)}% of your ${category} budget this month.`,
      data: { type: 'budget', category },
      channelId: 'budget-alerts',
    },
    trigger: null,
  });
};

export const cancelAllNotifications = async () => {
  await Notifications.cancelAllScheduledNotificationsAsync();
};
