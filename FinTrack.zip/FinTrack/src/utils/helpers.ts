// src/utils/helpers.ts
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { CATEGORIES_EXPENSE, CATEGORIES_INCOME } from '../constants/theme';
import { Transaction } from '../database/db';

export const formatCurrency = (amount: number, currency = '₹'): string => {
  const abs = Math.abs(amount);
  if (abs >= 10000000) return `${currency}${(abs / 10000000).toFixed(2)}Cr`;
  if (abs >= 100000) return `${currency}${(abs / 100000).toFixed(2)}L`;
  if (abs >= 1000) return `${currency}${abs.toLocaleString('en-IN')}`;
  return `${currency}${abs.toFixed(2)}`;
};

export const formatCompact = (amount: number, currency = '₹'): string => {
  return `${currency}${Math.abs(amount).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
};

export const currentMonth = () => format(new Date(), 'yyyy-MM');
export const currentMonthLabel = () => format(new Date(), 'MMMM yyyy');

export const getMonthRange = (month: string) => {
  const date = new Date(`${month}-01`);
  return {
    start: format(startOfMonth(date), 'yyyy-MM-dd'),
    end: format(endOfMonth(date), 'yyyy-MM-dd'),
  };
};

export const last6Months = () => {
  return Array.from({ length: 6 }, (_, i) => {
    const d = subMonths(new Date(), 5 - i);
    return { key: format(d, 'yyyy-MM'), label: format(d, 'MMM') };
  });
};

export const getCategoryInfo = (id: string, type: string) => {
  const list = type === 'income' ? CATEGORIES_INCOME : CATEGORIES_EXPENSE;
  return list.find(c => c.id === id) ?? { id, label: id, icon: '💰', color: '#8395a7' };
};

export const formatDate = (dateStr: string): string => {
  const d = new Date(dateStr + 'T00:00:00');
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);

  if (d.toDateString() === today.toDateString()) return 'Today';
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
  return format(d, 'd MMM yyyy');
};

export const groupByDate = (transactions: Transaction[]) => {
  const groups: Record<string, Transaction[]> = {};
  transactions.forEach(t => {
    const label = formatDate(t.date);
    if (!groups[label]) groups[label] = [];
    groups[label].push(t);
  });
  return Object.entries(groups);
};

export const generateId = () => {
  return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

export const exportToCSV = async (transactions: Transaction[]): Promise<void> => {
  const headers = ['Date', 'Type', 'Category', 'Amount', 'Account', 'Notes'];
  const rows = transactions.map(t => [
    t.date, t.type, t.category, t.amount.toString(),
    t.account_name ?? t.account_id, t.notes ?? ''
  ]);

  const csv = [headers, ...rows]
    .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    .join('\n');

  const fileName = `fintrack_${format(new Date(), 'yyyy-MM-dd')}.csv`;
  const filePath = `${FileSystem.documentDirectory}${fileName}`;

  await FileSystem.writeAsStringAsync(filePath, csv, {
    encoding: FileSystem.EncodingType.UTF8,
  });

  const canShare = await Sharing.isAvailableAsync();
  if (canShare) {
    await Sharing.shareAsync(filePath, {
      mimeType: 'text/csv',
      dialogTitle: 'Export FinTrack Data',
    });
  }
};

export const exportToJSON = async (data: object): Promise<void> => {
  const json = JSON.stringify(data, null, 2);
  const fileName = `fintrack_backup_${format(new Date(), 'yyyy-MM-dd')}.json`;
  const filePath = `${FileSystem.documentDirectory}${fileName}`;

  await FileSystem.writeAsStringAsync(filePath, json);
  const canShare = await Sharing.isAvailableAsync();
  if (canShare) {
    await Sharing.shareAsync(filePath, {
      mimeType: 'application/json',
      dialogTitle: 'Backup FinTrack Data',
    });
  }
};

export const getBudgetStatus = (spent: number, limit: number) => {
  const pct = Math.min(100, (spent / limit) * 100);
  if (pct >= 100) return { color: '#ff6b6b', label: 'Exceeded', pct };
  if (pct >= 80) return { color: '#ffb347', label: 'Warning', pct };
  return { color: '#00d4aa', label: 'Good', pct };
};
