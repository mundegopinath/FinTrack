// src/constants/theme.ts

export const Colors = {
  // Backgrounds
  bg: '#0f1117',
  bg2: '#171a24',
  bg3: '#1e2130',
  bg4: '#252840',

  // Accents
  accent: '#6c63ff',
  accentLight: 'rgba(108, 99, 255, 0.15)',
  accent2: '#ff6584',

  // Semantic
  green: '#00d4aa',
  greenLight: 'rgba(0, 212, 170, 0.15)',
  amber: '#ffb347',
  amberLight: 'rgba(255, 179, 71, 0.15)',
  red: '#ff6b6b',
  redLight: 'rgba(255, 107, 107, 0.15)',
  blue: '#4db6ff',
  blueLight: 'rgba(77, 182, 255, 0.15)',

  // Text
  text: '#f0f2ff',
  text2: '#a0a8cc',
  text3: '#5a6080',

  // Borders
  border: '#2a2d45',
  border2: '#353858',

  // Light theme overrides
  light: {
    bg: '#f5f6fa',
    bg2: '#ffffff',
    bg3: '#eef0f7',
    bg4: '#e5e8f0',
    text: '#1a1d2e',
    text2: '#5a6080',
    text3: '#9099bb',
    border: '#dde0ee',
    border2: '#c8ccdd',
  }
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};

export const BorderRadius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  full: 999,
};

export const FontSize = {
  xs: 11,
  sm: 12,
  md: 14,
  lg: 16,
  xl: 18,
  xxl: 22,
  xxxl: 28,
  display: 36,
};

export const CATEGORIES_EXPENSE = [
  { id: 'food', label: 'Food', icon: '🍜', color: '#ff6b6b' },
  { id: 'transport', label: 'Travel', icon: '🚗', color: '#ffd93d' },
  { id: 'shopping', label: 'Shopping', icon: '🛍️', color: '#6c63ff' },
  { id: 'bills', label: 'Bills', icon: '⚡', color: '#ff9f43' },
  { id: 'health', label: 'Health', icon: '💊', color: '#00d4aa' },
  { id: 'entertainment', label: 'Fun', icon: '🎮', color: '#f368e0' },
  { id: 'rent', label: 'Rent', icon: '🏠', color: '#48dbfb' },
  { id: 'education', label: 'Study', icon: '📚', color: '#a29bfe' },
  { id: 'investment', label: 'Invest', icon: '📈', color: '#55efc4' },
  { id: 'other', label: 'Other', icon: '📦', color: '#8395a7' },
];

export const CATEGORIES_INCOME = [
  { id: 'salary', label: 'Salary', icon: '💼', color: '#00d4aa' },
  { id: 'freelance', label: 'Freelance', icon: '💻', color: '#6c63ff' },
  { id: 'investment', label: 'Returns', icon: '📈', color: '#ffd93d' },
  { id: 'gift', label: 'Gift', icon: '🎁', color: '#ff6b6b' },
  { id: 'rental', label: 'Rental', icon: '🏘️', color: '#48dbfb' },
  { id: 'business', label: 'Business', icon: '🏪', color: '#ff9f43' },
  { id: 'other', label: 'Other', icon: '💰', color: '#8395a7' },
];

export const ACCOUNT_TYPES = [
  { id: 'cash', label: 'Cash', icon: '💵', color: '#00d4aa' },
  { id: 'bank', label: 'Bank Account', icon: '🏦', color: '#6c63ff' },
  { id: 'credit', label: 'Credit Card', icon: '💳', color: '#ff6b6b' },
  { id: 'upi', label: 'UPI Wallet', icon: '📱', color: '#ffd93d' },
  { id: 'savings', label: 'Savings', icon: '🏦', color: '#48dbfb' },
  { id: 'investment', label: 'Investment', icon: '📈', color: '#a29bfe' },
];

export const RECURRENCE_OPTIONS = [
  { id: 'none', label: 'None' },
  { id: 'daily', label: 'Daily' },
  { id: 'weekly', label: 'Weekly' },
  { id: 'monthly', label: 'Monthly' },
  { id: 'yearly', label: 'Yearly' },
];
