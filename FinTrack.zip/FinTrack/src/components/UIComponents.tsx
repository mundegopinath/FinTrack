// src/components/UIComponents.tsx
import React from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ActivityIndicator,
  TextInput, Modal, ScrollView, Dimensions
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, BorderRadius, FontSize } from '../constants/theme';
import { formatCurrency } from '../utils/helpers';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

// ─── CARD ────────────────────────────────────────────────────────────────────
export const Card = ({ children, style, onPress }: any) => {
  const content = (
    <View style={[styles.card, style]}>
      {children}
    </View>
  );
  if (onPress) return <TouchableOpacity onPress={onPress} activeOpacity={0.8}>{content}</TouchableOpacity>;
  return content;
};

// ─── BALANCE CARD ────────────────────────────────────────────────────────────
export const BalanceCard = ({ balance, income, expense, currency = '₹' }: any) => (
  <LinearGradient
    colors={['#1a1d35', '#252840']}
    style={styles.balanceCard}
    start={{ x: 0, y: 0 }}
    end={{ x: 1, y: 1 }}
  >
    <Text style={styles.balanceLabel}>Total Balance</Text>
    <Text style={styles.balanceAmount}>{formatCurrency(balance, currency)}</Text>
    <View style={styles.incExpRow}>
      <View style={styles.incExpItem}>
        <View style={[styles.incExpDot, { backgroundColor: Colors.green }]} />
        <Text style={styles.incExpLabel}>Income</Text>
        <Text style={[styles.incExpAmt, { color: Colors.green }]}>{formatCurrency(income, currency)}</Text>
      </View>
      <View style={styles.incExpDivider} />
      <View style={styles.incExpItem}>
        <View style={[styles.incExpDot, { backgroundColor: Colors.red }]} />
        <Text style={styles.incExpLabel}>Expenses</Text>
        <Text style={[styles.incExpAmt, { color: Colors.red }]}>{formatCurrency(expense, currency)}</Text>
      </View>
    </View>
  </LinearGradient>
);

// ─── TX ITEM ─────────────────────────────────────────────────────────────────
export const TxItem = ({ tx, onPress, onLongPress, currency = '₹' }: any) => {
  const isInc = tx.type === 'income';
  return (
    <TouchableOpacity
      style={styles.txItem}
      onPress={onPress}
      onLongPress={onLongPress}
      activeOpacity={0.7}
    >
      <View style={[styles.txIconWrap, { backgroundColor: tx.color + '22' }]}>
        <Text style={styles.txIcon}>{tx.icon}</Text>
      </View>
      <View style={styles.txInfo}>
        <Text style={styles.txTitle} numberOfLines={1}>
          {tx.categoryLabel}{tx.notes ? ` — ${tx.notes}` : ''}
        </Text>
        <Text style={styles.txSub}>{tx.account_name} · {tx.date}</Text>
      </View>
      <Text style={[styles.txAmt, { color: isInc ? Colors.green : Colors.red }]}>
        {isInc ? '+' : '-'}{formatCurrency(tx.amount, currency)}
      </Text>
    </TouchableOpacity>
  );
};

// ─── STAT CARD ────────────────────────────────────────────────────────────────
export const StatCard = ({ icon, label, value, color, style }: any) => (
  <View style={[styles.statCard, style]}>
    <Text style={styles.statIcon}>{icon}</Text>
    <Text style={styles.statLabel}>{label}</Text>
    <Text style={[styles.statValue, color ? { color } : {}]}>{value}</Text>
  </View>
);

// ─── PROGRESS BAR ────────────────────────────────────────────────────────────
export const ProgressBar = ({ pct, color }: { pct: number; color: string }) => (
  <View style={styles.progressWrap}>
    <View style={[styles.progressFill, { width: `${Math.min(100, pct)}%` as any, backgroundColor: color }]} />
  </View>
);

// ─── CATEGORY CHIP ────────────────────────────────────────────────────────────
export const CategoryChip = ({ cat, selected, onPress }: any) => (
  <TouchableOpacity
    style={[styles.catChip, selected && { borderColor: Colors.accent, backgroundColor: Colors.accentLight }]}
    onPress={onPress}
    activeOpacity={0.7}
  >
    <Text style={styles.catIcon}>{cat.icon}</Text>
    <Text style={[styles.catLabel, selected && { color: Colors.accent }]}>{cat.label}</Text>
  </TouchableOpacity>
);

// ─── FILTER CHIP ─────────────────────────────────────────────────────────────
export const FilterChip = ({ label, active, onPress }: any) => (
  <TouchableOpacity
    style={[styles.filterChip, active && styles.filterChipActive]}
    onPress={onPress}
    activeOpacity={0.7}
  >
    <Text style={[styles.filterLabel, active && styles.filterLabelActive]}>{label}</Text>
  </TouchableOpacity>
);

// ─── PRIMARY BUTTON ───────────────────────────────────────────────────────────
export const PrimaryButton = ({ label, onPress, loading, style }: any) => (
  <TouchableOpacity
    style={[styles.primaryBtn, style]}
    onPress={onPress}
    activeOpacity={0.85}
    disabled={loading}
  >
    <LinearGradient
      colors={[Colors.accent, Colors.accent2]}
      style={styles.primaryBtnGradient}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 0 }}
    >
      {loading
        ? <ActivityIndicator color="#fff" />
        : <Text style={styles.primaryBtnText}>{label}</Text>
      }
    </LinearGradient>
  </TouchableOpacity>
);

// ─── SECTION HEADER ───────────────────────────────────────────────────────────
export const SectionHeader = ({ title, action, onAction }: any) => (
  <View style={styles.sectionHeader}>
    <Text style={styles.sectionTitle}>{title}</Text>
    {action && (
      <TouchableOpacity onPress={onAction}>
        <Text style={styles.sectionAction}>{action}</Text>
      </TouchableOpacity>
    )}
  </View>
);

// ─── AMOUNT INPUT ─────────────────────────────────────────────────────────────
export const AmountInput = ({ value, onChange, currency = '₹', style }: any) => (
  <View style={[styles.amountWrap, style]}>
    <Text style={styles.currencySymbol}>{currency}</Text>
    <TextInput
      style={styles.amountInput}
      value={value}
      onChangeText={onChange}
      keyboardType="decimal-pad"
      placeholder="0.00"
      placeholderTextColor={Colors.text3}
    />
  </View>
);

// ─── FIELD ────────────────────────────────────────────────────────────────────
export const Field = ({ label, children, style }: any) => (
  <View style={[styles.field, style]}>
    <Text style={styles.fieldLabel}>{label}</Text>
    {children}
  </View>
);

// ─── EMPTY STATE ──────────────────────────────────────────────────────────────
export const EmptyState = ({ icon = '🔍', title, subtitle, action, onAction }: any) => (
  <View style={styles.emptyState}>
    <Text style={styles.emptyIcon}>{icon}</Text>
    <Text style={styles.emptyTitle}>{title}</Text>
    {subtitle && <Text style={styles.emptySub}>{subtitle}</Text>}
    {action && <PrimaryButton label={action} onPress={onAction} style={{ marginTop: 16 }} />}
  </View>
);

// ─── TYPE TOGGLE ──────────────────────────────────────────────────────────────
export const TypeToggle = ({ value, onChange }: any) => {
  const types = [
    { id: 'expense', label: 'Expense', color: Colors.red },
    { id: 'income', label: 'Income', color: Colors.green },
    { id: 'transfer', label: 'Transfer', color: Colors.blue },
  ];
  return (
    <View style={styles.typeToggle}>
      {types.map(t => (
        <TouchableOpacity
          key={t.id}
          style={[styles.typeBtn, value === t.id && { backgroundColor: t.color }]}
          onPress={() => onChange(t.id)}
          activeOpacity={0.8}
        >
          <Text style={[styles.typeBtnText, value === t.id && { color: '#fff' }]}>{t.label}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};

// ─── BOTTOM SHEET MODAL ───────────────────────────────────────────────────────
export const BottomSheet = ({ visible, onClose, title, children }: any) => (
  <Modal
    visible={visible}
    transparent
    animationType="slide"
    onRequestClose={onClose}
  >
    <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={onClose} />
    <View style={styles.sheet}>
      <View style={styles.sheetHandle} />
      {title && <Text style={styles.sheetTitle}>{title}</Text>}
      <ScrollView showsVerticalScrollIndicator={false}>
        {children}
      </ScrollView>
    </View>
  </Modal>
);

// ─── STYLES ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.bg2,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
  },
  balanceCard: {
    margin: Spacing.lg,
    borderRadius: BorderRadius.xl,
    padding: Spacing.xxl,
    borderWidth: 1,
    borderColor: Colors.border2,
  },
  balanceLabel: {
    fontSize: FontSize.xs,
    color: Colors.text2,
    letterSpacing: 0.5,
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  balanceAmount: {
    fontSize: 36,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: Spacing.lg,
  },
  incExpRow: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: BorderRadius.md,
    overflow: 'hidden',
  },
  incExpItem: { flex: 1, padding: Spacing.md, alignItems: 'center' },
  incExpDivider: { width: 1, backgroundColor: Colors.border2 },
  incExpDot: { width: 8, height: 8, borderRadius: 4, marginBottom: 4 },
  incExpLabel: { fontSize: FontSize.xs, color: Colors.text2, marginBottom: 2 },
  incExpAmt: { fontSize: FontSize.md, fontWeight: '700' },

  txItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  txIconWrap: {
    width: 44,
    height: 44,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  txIcon: { fontSize: 22 },
  txInfo: { flex: 1, marginRight: Spacing.sm },
  txTitle: { fontSize: FontSize.md, fontWeight: '500', color: Colors.text },
  txSub: { fontSize: FontSize.xs, color: Colors.text2, marginTop: 2 },
  txAmt: { fontSize: FontSize.md, fontWeight: '700' },

  statCard: {
    backgroundColor: Colors.bg2,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.lg,
    flex: 1,
  },
  statIcon: { fontSize: 24, marginBottom: Spacing.sm },
  statLabel: { fontSize: FontSize.xs, color: Colors.text2, marginBottom: 4 },
  statValue: { fontSize: FontSize.xl, fontWeight: '700', color: Colors.text },

  progressWrap: {
    height: 8,
    backgroundColor: Colors.bg3,
    borderRadius: 4,
    overflow: 'hidden',
    marginVertical: Spacing.sm,
  },
  progressFill: { height: 8, borderRadius: 4 },

  catChip: {
    alignItems: 'center',
    padding: Spacing.sm,
    backgroundColor: Colors.bg3,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: Spacing.sm,
  },
  catIcon: { fontSize: 22, marginBottom: 2 },
  catLabel: { fontSize: 10, color: Colors.text2 },

  filterChip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    backgroundColor: Colors.bg3,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    borderColor: Colors.border,
    marginRight: Spacing.sm,
  },
  filterChipActive: { backgroundColor: Colors.accentLight, borderColor: Colors.accent },
  filterLabel: { fontSize: FontSize.sm, color: Colors.text2 },
  filterLabelActive: { color: Colors.accent },

  primaryBtn: { borderRadius: BorderRadius.md, overflow: 'hidden' },
  primaryBtnGradient: { paddingVertical: 16, alignItems: 'center', justifyContent: 'center' },
  primaryBtnText: { color: '#fff', fontSize: FontSize.lg, fontWeight: '700' },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.sm,
  },
  sectionTitle: { fontSize: FontSize.md, fontWeight: '600', color: Colors.text },
  sectionAction: { fontSize: FontSize.sm, color: Colors.accent },

  amountWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bg3,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.border2,
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  currencySymbol: { fontSize: 26, color: Colors.text3, marginRight: Spacing.sm },
  amountInput: {
    flex: 1,
    fontSize: 34,
    fontWeight: '700',
    color: Colors.text,
    paddingVertical: Spacing.md,
    textAlign: 'right',
  },

  field: { marginBottom: Spacing.lg },
  fieldLabel: {
    fontSize: FontSize.xs,
    color: Colors.text2,
    marginBottom: Spacing.sm,
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },

  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 40 },
  emptyIcon: { fontSize: 56, marginBottom: 16 },
  emptyTitle: { fontSize: FontSize.lg, fontWeight: '600', color: Colors.text, textAlign: 'center' },
  emptySub: { fontSize: FontSize.sm, color: Colors.text2, textAlign: 'center', marginTop: 8 },

  typeToggle: {
    flexDirection: 'row',
    backgroundColor: Colors.bg3,
    borderRadius: BorderRadius.md,
    padding: 4,
    marginBottom: Spacing.xl,
  },
  typeBtn: {
    flex: 1,
    paddingVertical: Spacing.md,
    alignItems: 'center',
    borderRadius: BorderRadius.sm,
  },
  typeBtnText: { fontSize: FontSize.sm, fontWeight: '600', color: Colors.text2 },

  overlay: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.6)',
  },
  sheet: {
    backgroundColor: Colors.bg2,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: Spacing.xl,
    paddingBottom: 40,
    borderTopWidth: 1,
    borderColor: Colors.border,
    maxHeight: '85%',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  sheetHandle: {
    width: 36,
    height: 4,
    backgroundColor: Colors.border2,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: Spacing.lg,
  },
  sheetTitle: {
    fontSize: FontSize.lg,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: Spacing.lg,
  },
});
