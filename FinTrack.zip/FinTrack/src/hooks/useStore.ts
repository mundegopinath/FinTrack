// src/hooks/useStore.ts
import { create } from 'zustand';
import { Account, Transaction, Budget, Goal } from '../database/db';

interface AppState {
  accounts: Account[];
  transactions: Transaction[];
  budgets: Budget[];
  goals: Goal[];
  isDarkMode: boolean;
  currency: string;
  isLoading: boolean;
  activeTab: string;

  setAccounts: (accounts: Account[]) => void;
  setTransactions: (transactions: Transaction[]) => void;
  setBudgets: (budgets: Budget[]) => void;
  setGoals: (goals: Goal[]) => void;
  setDarkMode: (val: boolean) => void;
  setCurrency: (val: string) => void;
  setLoading: (val: boolean) => void;
  setActiveTab: (tab: string) => void;
}

export const useStore = create<AppState>((set) => ({
  accounts: [],
  transactions: [],
  budgets: [],
  goals: [],
  isDarkMode: true,
  currency: '₹',
  isLoading: true,
  activeTab: 'dashboard',

  setAccounts: (accounts) => set({ accounts }),
  setTransactions: (transactions) => set({ transactions }),
  setBudgets: (budgets) => set({ budgets }),
  setGoals: (goals) => set({ goals }),
  setDarkMode: (isDarkMode) => set({ isDarkMode }),
  setCurrency: (currency) => set({ currency }),
  setLoading: (isLoading) => set({ isLoading }),
  setActiveTab: (activeTab) => set({ activeTab }),
}));
