// src/screens/DashboardScreen.tsx
import React, { useCallback, useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, RefreshControl,
  TouchableOpacity, Dimensions
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { LineChart, PieChart } from 'react-native-chart-kit';
import { format } from 'date-fns';
import {
  getTransactions, getAccounts, getMonthlyTotals,
  getCategoryBreakdown, getLast6MonthsData
} from '../database/db';
import {
  BalanceCard, SectionHeader, TxItem, EmptyState, Card
} from '../components/UIComponents';
import { Colors, Spacing, FontSize, BorderRadius, CATEGORIES_EXPENSE } from '../constants/theme';
import { formatCurrency, currentMonth, last6Months, getCategoryInfo } from '../utils/helpers';

const { width: SCREEN_W } = Dimensions.get('window');

export default function DashboardScreen({ navigation }: any) {
  const [data, setData] = useState({
    balance: 0, income: 0, expense: 0,
    recentTx: [] as any[], catBreakdown: [] as any[],
    monthlyData: [] as any[],
  });
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    const month = currentMonth();
    const [accounts, totals, breakdown, last6, recent] = await Promise.all([
      getAccounts(),
      getMonthlyTotals(month),
      getCategoryBreakdown(month),
      getLast6MonthsData(),
      getTransactions({ limit: 6 }),
    ]);

    const balance = accounts.reduce((s, a) => s + a.balance, 0);

    const recentTx = recent.map(t => {
      const cat = getCategoryInfo(t.category, t.type);
      return { ...t, icon: cat.icon, color: cat.color, categoryLabel: cat.label };
    });

    const catBreakdown = breakdown.slice(0, 5).map(b => {
      const cat = CATEGORIES_EXPENSE.find(c => c.id === b.category) ?? { label: b.category, color: '#8395a7' };
      return { ...b, ...cat };
    });

    setData({ balance, income: totals.income, expense: totals.expense, recentTx, catBreakdown, monthlyData: last6 });
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const months = last6Months();
  const incomeByMonth = months.map(m => {
    const row = data.monthlyData.find(d => d.month === m.key && d.type === 'income');
    return row ? row.total : 0;
  });
  const expenseByMonth = months.map(m => {
    const row = data.monthlyData.find(d => d.month === m.key && d.type === 'expense');
    return row ? row.total : 0;
  });

  const pieData = data.catBreakdown.map(c => ({
    name: c.label,
    population: c.total,
    color: c.color,
    legendFontColor: Colors.text2,
    legendFontSize: 11,
  }));

  const chartConfig = {
    backgroundGradientFrom: Colors.bg2,
    backgroundGradientTo: Colors.bg2,
    color: (opacity = 1) => `rgba(108,99,255,${opacity})`,
    labelColor: () => Colors.text2,
    strokeWidth: 2,
    propsForDots: { r: '4', strokeWidth: '2', stroke: Colors.accent },
    decimalPlaces: 0,
  };

  return (
    <ScrollView
      style={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.accent} />}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Good {getGreeting()},</Text>
          <Text style={styles.month}>{format(new Date(), 'MMMM yyyy')}</Text>
        </View>
        <TouchableOpacity style={styles.notifBtn}>
          <Text style={{ fontSize: 22 }}>🔔</Text>
        </TouchableOpacity>
      </View>

      <BalanceCard
        balance={data.balance}
        income={data.income}
        expense={data.expense}
      />

      {/* SPENDING PIE */}
      {pieData.length > 0 && (
        <>
          <SectionHeader title="Spending Breakdown" />
          <Card style={styles.chartCard}>
            <PieChart
              data={pieData}
              width={SCREEN_W - 64}
              height={180}
              chartConfig={chartConfig}
              accessor="population"
              backgroundColor="transparent"
              paddingLeft="0"
              hasLegend
              absolute={false}
            />
          </Card>
        </>
      )}

      {/* MONTHLY LINE CHART */}
      <SectionHeader title="Income vs Expenses" />
      <Card style={styles.chartCard}>
        <LineChart
          data={{
            labels: months.map(m => m.label),
            datasets: [
              { data: incomeByMonth, color: () => Colors.green, strokeWidth: 2 },
              { data: expenseByMonth, color: () => Colors.red, strokeWidth: 2 },
            ],
            legend: ['Income', 'Expense'],
          }}
          width={SCREEN_W - 64}
          height={200}
          chartConfig={chartConfig}
          bezier
          style={{ borderRadius: 8 }}
          withDots={true}
          withInnerLines={false}
          withOuterLines={false}
        />
      </Card>

      {/* RECENT TX */}
      <SectionHeader
        title="Recent Transactions"
        action="See all"
        onAction={() => navigation.navigate('Transactions')}
      />
      <View style={styles.txWrap}>
        {data.recentTx.length === 0
          ? <EmptyState icon="💸" title="No transactions yet" subtitle="Tap + to add your first entry" />
          : data.recentTx.map(t => (
            <TxItem
              key={t.id}
              tx={t}
              onPress={() => navigation.navigate('TransactionDetail', { tx: t })}
            />
          ))
        }
      </View>
      <View style={{ height: 100 }} />
    </ScrollView>
  );
}

const getGreeting = () => {
  const h = new Date().getHours();
  if (h < 12) return 'morning';
  if (h < 17) return 'afternoon';
  return 'evening';
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingTop: Spacing.xl, paddingBottom: Spacing.sm,
  },
  greeting: { fontSize: FontSize.sm, color: Colors.text2 },
  month: { fontSize: FontSize.xl, fontWeight: '700', color: Colors.text },
  notifBtn: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: Colors.bg2, borderWidth: 1, borderColor: Colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
  chartCard: { marginHorizontal: Spacing.lg, alignItems: 'center' },
  txWrap: { paddingHorizontal: Spacing.lg },
});
