// src/screens/SettingsScreen.tsx
import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  Switch, Alert
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getTransactions, getAccounts, getGoals } from '../database/db';
import { getSetting, setSetting } from '../database/db';
import { Colors, Spacing, FontSize, BorderRadius } from '../constants/theme';
import { exportToCSV, exportToJSON } from '../utils/helpers';
import {
  scheduleDailyReminder, cancelAllNotifications,
  requestNotificationPermissions
} from '../utils/notifications';

interface SettingItem {
  icon: string;
  label: string;
  sub?: string;
  value?: any;
  onPress?: () => void;
  toggle?: boolean;
  color?: string;
}

export default function SettingsScreen() {
  const [notifEnabled, setNotifEnabled] = useState(true);
  const [reminderEnabled, setReminderEnabled] = useState(false);

  useFocusEffect(useCallback(() => {
    getSetting('notification_enabled').then(v => setNotifEnabled(v === '1'));
    getSetting('reminder_enabled').then(v => setReminderEnabled(v === '1'));
  }, []));

  const toggleNotif = async (val: boolean) => {
    setNotifEnabled(val);
    await setSetting('notification_enabled', val ? '1' : '0');
    if (val) await requestNotificationPermissions();
  };

  const toggleReminder = async (val: boolean) => {
    setReminderEnabled(val);
    await setSetting('reminder_enabled', val ? '1' : '0');
    if (val) {
      const ok = await requestNotificationPermissions();
      if (ok) {
        await scheduleDailyReminder(21, 0);
        Alert.alert('Reminder Set', 'You will be reminded daily at 9:00 PM to log transactions.');
      }
    } else {
      await cancelAllNotifications();
    }
  };

  const handleExportCSV = async () => {
    try {
      const txs = await getTransactions({});
      await exportToCSV(txs);
    } catch (e) {
      Alert.alert('Export Failed', 'Could not export data.');
    }
  };

  const handleBackup = async () => {
    try {
      const [accounts, transactions, goals] = await Promise.all([
        getAccounts(), getTransactions({}), getGoals()
      ]);
      await exportToJSON({ accounts, transactions, goals, exportedAt: new Date().toISOString() });
    } catch (e) {
      Alert.alert('Backup Failed', 'Could not back up data.');
    }
  };

  const sections: { title: string; items: SettingItem[] }[] = [
    {
      title: 'Notifications',
      items: [
        {
          icon: '🔔',
          label: 'Budget Alerts',
          sub: 'Notify when budget limit is near',
          toggle: true,
          value: notifEnabled,
          onPress: () => toggleNotif(!notifEnabled),
          color: Colors.accentLight,
        },
        {
          icon: '⏰',
          label: 'Daily Reminder',
          sub: 'Remind to log at 9 PM',
          toggle: true,
          value: reminderEnabled,
          onPress: () => toggleReminder(!reminderEnabled),
          color: Colors.amberLight,
        },
      ],
    },
    {
      title: 'Data & Backup',
      items: [
        {
          icon: '📤',
          label: 'Export to CSV',
          sub: 'Download all transactions',
          onPress: handleExportCSV,
          color: Colors.greenLight,
        },
        {
          icon: '💾',
          label: 'Backup Data',
          sub: 'Export full backup as JSON',
          onPress: handleBackup,
          color: Colors.blueLight,
        },
      ],
    },
    {
      title: 'About',
      items: [
        { icon: '💜', label: 'FinTrack', sub: 'Version 1.0.0', color: Colors.accentLight },
        { icon: '🔒', label: 'Privacy', sub: 'All data stored locally', color: Colors.greenLight },
      ],
    },
  ];

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Profile Card */}
      <View style={styles.profileCard}>
        <View style={styles.avatar}>
          <Text style={{ fontSize: 32 }}>👤</Text>
        </View>
        <View>
          <Text style={styles.profileName}>My Finance</Text>
          <Text style={styles.profileSub}>Personal Account</Text>
        </View>
      </View>

      {sections.map(section => (
        <View key={section.title} style={styles.section}>
          <Text style={styles.sectionTitle}>{section.title}</Text>
          {section.items.map(item => (
            <TouchableOpacity
              key={item.label}
              style={styles.item}
              onPress={item.toggle ? undefined : item.onPress}
              activeOpacity={item.toggle ? 1 : 0.7}
            >
              <View style={[styles.itemIcon, { backgroundColor: item.color ?? Colors.bg3 }]}>
                <Text style={{ fontSize: 18 }}>{item.icon}</Text>
              </View>
              <View style={styles.itemInfo}>
                <Text style={styles.itemLabel}>{item.label}</Text>
                {item.sub && <Text style={styles.itemSub}>{item.sub}</Text>}
              </View>
              {item.toggle
                ? <Switch
                    value={item.value}
                    onValueChange={item.onPress as any}
                    trackColor={{ false: Colors.bg4, true: Colors.accent }}
                    thumbColor="#fff"
                  />
                : <Text style={styles.chevron}>›</Text>
              }
            </TouchableOpacity>
          ))}
        </View>
      ))}

      <View style={{ height: 120 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  profileCard: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.lg,
    margin: Spacing.lg,
    backgroundColor: Colors.bg2, borderRadius: BorderRadius.xl,
    borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.xl,
  },
  avatar: {
    width: 60, height: 60, borderRadius: 30,
    backgroundColor: Colors.accentLight,
    alignItems: 'center', justifyContent: 'center',
  },
  profileName: { fontSize: FontSize.xl, fontWeight: '700', color: Colors.text },
  profileSub: { fontSize: FontSize.sm, color: Colors.text2, marginTop: 2 },
  section: { marginBottom: Spacing.xl, paddingHorizontal: Spacing.lg },
  sectionTitle: {
    fontSize: FontSize.xs, color: Colors.text3,
    textTransform: 'uppercase', letterSpacing: 0.5,
    marginBottom: Spacing.sm, paddingHorizontal: 4,
  },
  item: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.bg2, borderRadius: BorderRadius.lg,
    borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.lg, marginBottom: Spacing.sm,
  },
  itemIcon: {
    width: 40, height: 40, borderRadius: 12,
    alignItems: 'center', justifyContent: 'center', marginRight: Spacing.md,
  },
  itemInfo: { flex: 1 },
  itemLabel: { fontSize: FontSize.md, fontWeight: '500', color: Colors.text },
  itemSub: { fontSize: FontSize.xs, color: Colors.text2, marginTop: 2 },
  chevron: { fontSize: 22, color: Colors.text3 },
});
