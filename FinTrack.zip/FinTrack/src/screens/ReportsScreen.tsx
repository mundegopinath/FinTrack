// src/screens/ReportsScreen.tsx
import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity, Dimensions
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { BarChart } from 'react-native-chart-kit';
import {
  getTransactions, getMonthlyTotals, getCategoryBreakdown
} from '../database/db';
import { Card, SectionHeader } from '../components/UIComponents';
import { Colors, Spacing, FontSize, BorderRadius, CATEGORIES_EXPENSE } from '../constants/theme';
import { formatCompact, formatCurrency, last6Months, currentMonth, getCategoryInfo } from '../utils/helpers';

const { width: SCREEN_W } = Dimensions.get('window');

export default function ReportsScreen() {
  const [selMonth, setSelMonth] = useState(currentMonth());
  const [data, setData] = useState<any>({});
  const months = last6Months();

  const load = useCallback(async () => {
    const [totals, breakdown, allTx] = await Promise.all([
      getMonthlyTotals(selMonth),
      getCategoryBreakdown(selMonth),
      getTransactions({ type: 'expense', startDate: `${selMonth}-01`, endDate: `${selMonth}-31` }),
    ]);

    const savingsRate = totals.income > 0 ? ((totals.income - totals.expense) / totals.income) * 100 : 0;
    const topCat = breakdown[0];
    const avgDailySpend = totals.expense / 30;

    setData({ totals, breakdown, savingsRate, topCat, avgDailySpend, txCount: allTx.length });
  }, [selMonth]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const barData = {
    labels: ['Income', 'Expense', 'Savings'],
    datasets: [{
      data: [
        data.totals?.income ?? 0,
        data.totals?.expense ?? 0,
        Math.max(0, (data.totals?.income ?? 0) - (data.totals?.expense ?? 0)),
      ]
    }]
  };

  const chartConfig = {
    backgroundGradientFrom: Colors.bg2,
    backgroundGradientTo: Colors.bg2,
    color: (opacity = 1, idx?: number) => {
      const colors = [`rgba(0,212,170,${opacity})`, `rgba(255,107,107,${opacity})`, `rgba(108,99,255,${opacity})`];
      return colors[idx ?? 0] ?? colors[0];
    },
    labelColor: () => Colors.text2,
    strokeWidth: 2,
    decimalPlaces: 0,
    barPercentage: 0.6,
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Month Selector */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.monthRow}>
        {months.map(m => (
          <TouchableOpacity
            key={m.key}
            style={[styles.monthChip, selMonth === m.key && styles.monthChipActive]}
            onPress={() => setSelMonth(m.key)}
          >
            <Text style={[styles.monthLabel, selMonth === m.key && { color: Colors.accent }]}>{m.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Summary Stats */}
      <View style={styles.statsGrid}>
        <Card style={styles.statCard}>
          <Text style={styles.statIcon}>💰</Text>
          <Text style={styles.statLabel}>Income</Text>
          <Text style={[styles.statVal, { color: Colors.green }]}>{formatCompact(data.totals?.income ?? 0)}</Text>
        </Card>
        <Card style={styles.statCard}>
          <Text style={styles.statIcon}>💸</Text>
          <Text style={styles.statLabel}>Expenses</Text>
          <Text style={[styles.statVal, { color: Colors.red }]}>{formatCompact(data.totals?.expense ?? 0)}</Text>
        </Card>
        <Card style={styles.statCard}>
          <Text style={styles.statIcon}>📊</Text>
          <Text style={styles.statLabel}>Savings Rate</Text>
          <Text style={[styles.statVal, { color: (data.savingsRate ?? 0) >= 0 ? Colors.green : Colors.red }]}>
            {Math.round(data.savingsRate ?? 0)}%
          </Text>
        </Card>
        <Card style={styles.statCard}>
          <Text style={styles.statIcon}>📅</Text>
          <Text style={styles.statLabel}>Avg/Day</Text>
          <Text style={styles.statVal}>{formatCompact(data.avgDailySpend ?? 0)}</Text>
        </Card>
      </View>

      {/* Bar Chart */}
      <SectionHeader title="Overview" />
      <Card style={styles.chartCard}>
        <BarChart
          data={barData}
          width={SCREEN_W - 64}
          height={200}
          chartConfig={chartConfig}
          style={{ borderRadius: 8 }}
          showValuesOnTopOfBars
          fromZero
          yAxisLabel="₹"
          yAxisSuffix=""
        />
      </Card>

      {/* Top Category */}
      {data.topCat && (
        <>
          <SectionHeader title="Top Spending Category" />
          <Card style={styles.insightCard}>
            {(() => {
              const cat = getCategoryInfo(data.topCat.category, 'expense');
              return (
                <View style={styles.insightRow}>
                  <View style={[styles.insightIcon, { backgroundColor: cat.color + '22' }]}>
                    <Text style={{ fontSize: 26 }}>{cat.icon}</Text>
                  </View>
                  <View>
                    <Text style={styles.insightLabel}>{cat.label}</Text>
                    <Text style={[styles.insightVal, { color: Colors.red }]}>
                      {formatCurrency(data.topCat.total)}
                    </Text>
                    <Text style={styles.insightSub}>
                      {data.totals?.expense > 0 ? Math.round((data.topCat.total / data.totals.expense) * 100) : 0}% of total expenses
                    </Text>
                  </View>
                </View>
              );
            })()}
          </Card>
        </>
      )}

      {/* Category Breakdown */}
      <SectionHeader title="Expense Breakdown" />
      {(data.breakdown ?? []).map((b: any) => {
        const cat = getCategoryInfo(b.category, 'expense');
        const pct = data.totals?.expense > 0 ? (b.total / data.totals.expense) * 100 : 0;
        return (
          <View key={b.category} style={styles.breakdownRow}>
            <View style={[styles.breakdownIcon, { backgroundColor: cat.color + '22' }]}>
              <Text style={{ fontSize: 16 }}>{cat.icon}</Text>
            </View>
            <View style={styles.breakdownInfo}>
              <View style={styles.breakdownHeader}>
                <Text style={styles.breakdownName}>{cat.label}</Text>
                <Text style={styles.breakdownAmt}>{formatCompact(b.total)}</Text>
              </View>
              <View style={styles.breakdownBar}>
                <View style={[styles.breakdownFill, { width: `${pct}%` as any, backgroundColor: cat.color }]} />
              </View>
            </View>
          </View>
        );
      })}

      {/* Insights */}
      <SectionHeader title="Insights" />
      <Card style={styles.insightCard}>
        <Text style={styles.insightBullet}>
          {data.savingsRate > 20
            ? `🎉 Great job! You saved ${Math.round(data.savingsRate)}% this month.`
            : data.savingsRate > 0
              ? `💡 You saved ${Math.round(data.savingsRate)}%. Try to reach 20%.`
              : `⚠️ Expenses exceeded income this month. Review your spending.`
          }
        </Text>
        {data.txCount > 0 && (
          <Text style={[styles.insightBullet, { marginTop: 8 }]}>
            📋 You made {data.txCount} transactions this month.
          </Text>
        )}
      </Card>

      <View style={{ height: 120 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  monthRow: { paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, gap: Spacing.sm },
  monthChip: {
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm,
    backgroundColor: Colors.bg2, borderRadius: BorderRadius.full,
    borderWidth: 1, borderColor: Colors.border,
  },
  monthChipActive: { borderColor: Colors.accent, backgroundColor: Colors.accentLight },
  monthLabel: { fontSize: FontSize.sm, color: Colors.text2, fontWeight: '500' },
  statsGrid: {
    flexDirection: 'row', flexWrap: 'wrap',
    paddingHorizontal: Spacing.lg, gap: Spacing.sm,
  },
  statCard: { flex: 1, minWidth: '45%', margin: 0, marginBottom: 0 },
  statIcon: { fontSize: 22, marginBottom: 4 },
  statLabel: { fontSize: FontSize.xs, color: Colors.text2 },
  statVal: { fontSize: FontSize.xl, fontWeight: '700', color: Colors.text, marginTop: 2 },
  chartCard: { marginHorizontal: Spacing.lg, alignItems: 'center' },
  insightCard: { marginHorizontal: Spacing.lg },
  insightRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.lg },
  insightIcon: { width: 52, height: 52, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  insightLabel: { fontSize: FontSize.lg, fontWeight: '600', color: Colors.text },
  insightVal: { fontSize: FontSize.xl, fontWeight: '700', marginTop: 2 },
  insightSub: { fontSize: FontSize.xs, color: Colors.text2, marginTop: 2 },
  insightBullet: { fontSize: FontSize.md, color: Colors.text, lineHeight: 22 },
  breakdownRow: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm,
  },
  breakdownIcon: {
    width: 36, height: 36, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center', marginRight: Spacing.md,
  },
  breakdownInfo: { flex: 1 },
  breakdownHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  breakdownName: { fontSize: FontSize.sm, color: Colors.text },
  breakdownAmt: { fontSize: FontSize.sm, fontWeight: '700', color: Colors.text },
  breakdownBar: { height: 6, backgroundColor: Colors.bg3, borderRadius: 3, overflow: 'hidden' },
  breakdownFill: { height: 6, borderRadius: 3 },
});
