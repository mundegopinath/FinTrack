// src/screens/AccountsScreen.tsx
import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  TextInput, Alert
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  getAccounts, createAccount, deleteAccount, Account
} from '../database/db';
import {
  SectionHeader, EmptyState, BottomSheet, PrimaryButton, Field
} from '../components/UIComponents';
import { Colors, Spacing, FontSize, BorderRadius, ACCOUNT_TYPES } from '../constants/theme';
import { formatCompact, generateId } from '../utils/helpers';

export default function AccountsScreen({ navigation }: any) {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState('');
  const [newType, setNewType] = useState('bank');
  const [newBalance, setNewBalance] = useState('');

  const load = useCallback(async () => {
    setAccounts(await getAccounts());
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const totalBalance = accounts.reduce((s, a) => s + a.balance, 0);

  const handleAdd = async () => {
    if (!newName.trim()) { Alert.alert('Error', 'Enter account name'); return; }
    const typeInfo = ACCOUNT_TYPES.find(t => t.id === newType) ?? ACCOUNT_TYPES[0];
    await createAccount({
      id: generateId(),
      name: newName.trim(),
      type: newType,
      balance: parseFloat(newBalance) || 0,
      color: typeInfo.color,
      icon: typeInfo.icon,
      is_default: 0,
    });
    setShowAdd(false);
    setNewName('');
    setNewBalance('');
    load();
  };

  const handleDelete = (acc: Account) => {
    if (acc.is_default) { Alert.alert('Error', 'Cannot delete default account'); return; }
    Alert.alert('Delete Account', `Remove "${acc.name}"? All its transactions remain.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => { await deleteAccount(acc.id); load(); } }
    ]);
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Net Worth Card */}
      <LinearGradient
        colors={['#1a1d35', '#252840']}
        style={styles.netCard}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <Text style={styles.netLabel}>Net Worth</Text>
        <Text style={[styles.netAmount, { color: totalBalance >= 0 ? Colors.green : Colors.red }]}>
          {totalBalance < 0 ? '-' : ''}₹{Math.abs(totalBalance).toLocaleString('en-IN')}
        </Text>
        <Text style={styles.netSub}>{accounts.length} accounts</Text>
      </LinearGradient>

      <SectionHeader title="My Accounts" action="+ Add" onAction={() => setShowAdd(true)} />

      {accounts.length === 0
        ? <EmptyState icon="💳" title="No accounts yet" subtitle="Add your first account to get started" />
        : accounts.map(acc => {
          const typeInfo = ACCOUNT_TYPES.find(t => t.id === acc.type) ?? ACCOUNT_TYPES[0];
          return (
            <TouchableOpacity
              key={acc.id}
              style={styles.accCard}
              onLongPress={() => handleDelete(acc)}
              activeOpacity={0.85}
            >
              <View style={[styles.accIconWrap, { backgroundColor: acc.color + '22' }]}>
                <Text style={{ fontSize: 26 }}>{acc.icon}</Text>
              </View>
              <View style={styles.accInfo}>
                <Text style={styles.accName}>{acc.name}</Text>
                <Text style={styles.accType}>{typeInfo.label}</Text>
              </View>
              <View style={styles.accRight}>
                <Text style={[styles.accBalance, { color: acc.balance < 0 ? Colors.red : Colors.text }]}>
                  {acc.balance < 0 ? '-' : ''}₹{Math.abs(acc.balance).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                </Text>
                {acc.is_default === 1 && (
                  <View style={styles.defaultBadge}>
                    <Text style={styles.defaultText}>Default</Text>
                  </View>
                )}
              </View>
            </TouchableOpacity>
          );
        })
      }

      <Text style={styles.hint}>Long press an account to delete</Text>
      <View style={{ height: 120 }} />

      {/* Add Account Sheet */}
      <BottomSheet visible={showAdd} onClose={() => setShowAdd(false)} title="Add Account">
        <Field label="Account Name">
          <TextInput
            style={styles.input}
            value={newName}
            onChangeText={setNewName}
            placeholder="e.g. SBI Savings"
            placeholderTextColor={Colors.text3}
          />
        </Field>
        <Field label="Account Type">
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={{ flexDirection: 'row', gap: 8, paddingBottom: 8 }}>
              {ACCOUNT_TYPES.map(t => (
                <TouchableOpacity
                  key={t.id}
                  style={[styles.typePill, newType === t.id && styles.typePillActive]}
                  onPress={() => setNewType(t.id)}
                >
                  <Text style={styles.typePillText}>{t.icon} {t.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </Field>
        <Field label="Opening Balance (₹)">
          <TextInput
            style={styles.input}
            value={newBalance}
            onChangeText={setNewBalance}
            keyboardType="decimal-pad"
            placeholder="0"
            placeholderTextColor={Colors.text3}
          />
        </Field>
        <PrimaryButton label="Add Account" onPress={handleAdd} />
      </BottomSheet>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  netCard: {
    margin: Spacing.lg, borderRadius: BorderRadius.xl,
    padding: Spacing.xxl, borderWidth: 1, borderColor: Colors.border2,
  },
  netLabel: { fontSize: FontSize.xs, color: Colors.text2, textTransform: 'uppercase', letterSpacing: 0.5 },
  netAmount: { fontSize: 38, fontWeight: '700', marginVertical: 4 },
  netSub: { fontSize: FontSize.sm, color: Colors.text2 },
  accCard: {
    flexDirection: 'row', alignItems: 'center',
    marginHorizontal: Spacing.lg, marginBottom: Spacing.sm,
    backgroundColor: Colors.bg2, borderRadius: BorderRadius.lg,
    borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.lg,
  },
  accIconWrap: {
    width: 52, height: 52, borderRadius: 16,
    alignItems: 'center', justifyContent: 'center', marginRight: Spacing.md,
  },
  accInfo: { flex: 1 },
  accName: { fontSize: FontSize.lg, fontWeight: '600', color: Colors.text },
  accType: { fontSize: FontSize.sm, color: Colors.text2, marginTop: 2 },
  accRight: { alignItems: 'flex-end' },
  accBalance: { fontSize: FontSize.lg, fontWeight: '700' },
  defaultBadge: {
    backgroundColor: Colors.accentLight, borderRadius: 4,
    paddingHorizontal: 6, paddingVertical: 2, marginTop: 4,
  },
  defaultText: { fontSize: 10, color: Colors.accent, fontWeight: '600' },
  hint: { textAlign: 'center', fontSize: FontSize.xs, color: Colors.text3, marginTop: 8 },
  input: {
    backgroundColor: Colors.bg3, borderRadius: BorderRadius.md,
    borderWidth: 1, borderColor: Colors.border2,
    padding: Spacing.md, color: Colors.text, fontSize: FontSize.md,
  },
  typePill: {
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    backgroundColor: Colors.bg3, borderRadius: BorderRadius.full,
    borderWidth: 1, borderColor: Colors.border,
  },
  typePillActive: { borderColor: Colors.accent, backgroundColor: Colors.accentLight },
  typePillText: { fontSize: FontSize.sm, color: Colors.text },
});
