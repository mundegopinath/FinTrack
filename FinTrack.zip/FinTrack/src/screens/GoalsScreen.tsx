// src/screens/GoalsScreen.tsx
import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  TextInput, Alert
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getGoals, createGoal, deleteGoal, updateGoalAmount, Goal } from '../database/db';
import {
  SectionHeader, EmptyState, BottomSheet, PrimaryButton,
  Field, ProgressBar, Card
} from '../components/UIComponents';
import { Colors, Spacing, FontSize, BorderRadius } from '../constants/theme';
import { formatCompact, generateId } from '../utils/helpers';

const GOAL_ICONS = ['🎯', '🏠', '🚗', '✈️', '📱', '💍', '🎓', '💰', '🏖️', '👶'];
const GOAL_COLORS = ['#6c63ff', '#00d4aa', '#ff6b6b', '#ffb347', '#48dbfb', '#f368e0'];

export default function GoalsScreen() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [showContrib, setShowContrib] = useState<Goal | null>(null);
  const [name, setName] = useState('');
  const [target, setTarget] = useState('');
  const [targetDate, setTargetDate] = useState('');
  const [selIcon, setSelIcon] = useState('🎯');
  const [selColor, setSelColor] = useState('#6c63ff');
  const [contribAmt, setContribAmt] = useState('');

  const load = useCallback(async () => {
    setGoals(await getGoals());
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const handleAdd = async () => {
    if (!name.trim()) { Alert.alert('Error', 'Enter a goal name'); return; }
    const t = parseFloat(target);
    if (!t || t <= 0) { Alert.alert('Error', 'Enter a valid target amount'); return; }
    await createGoal({
      id: generateId(),
      name: name.trim(),
      target_amount: t,
      current_amount: 0,
      target_date: targetDate || undefined,
      icon: selIcon,
      color: selColor,
    });
    setShowAdd(false);
    setName(''); setTarget(''); setTargetDate('');
    load();
  };

  const handleContrib = async () => {
    if (!showContrib) return;
    const amt = parseFloat(contribAmt);
    if (!amt || amt <= 0) { Alert.alert('Error', 'Enter a valid amount'); return; }
    await updateGoalAmount(showContrib.id, amt);
    setShowContrib(null);
    setContribAmt('');
    load();
  };

  const handleDelete = (g: Goal) => {
    Alert.alert('Delete Goal', `Remove "${g.name}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => { await deleteGoal(g.id); load(); } }
    ]);
  };

  const totalSaved = goals.reduce((s, g) => s + g.current_amount, 0);
  const totalTarget = goals.reduce((s, g) => s + g.target_amount, 0);

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {goals.length > 0 && (
        <Card style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>Total Saved</Text>
          <Text style={styles.summaryAmt}>{formatCompact(totalSaved)} <Text style={styles.summaryOf}>of {formatCompact(totalTarget)}</Text></Text>
          <ProgressBar pct={(totalSaved / totalTarget) * 100} color={Colors.accent} />
        </Card>
      )}

      <SectionHeader title="My Goals" action="+ Add Goal" onAction={() => setShowAdd(true)} />

      {goals.length === 0
        ? <EmptyState icon="🎯" title="No goals yet" subtitle="Set financial goals to stay motivated" />
        : goals.map(g => {
          const pct = Math.min(100, (g.current_amount / g.target_amount) * 100);
          const completed = pct >= 100;
          return (
            <TouchableOpacity
              key={g.id}
              style={styles.goalCard}
              onPress={() => setShowContrib(g)}
              onLongPress={() => handleDelete(g)}
              activeOpacity={0.85}
            >
              <View style={styles.goalHeader}>
                <View style={[styles.goalIcon, { backgroundColor: g.color + '22' }]}>
                  <Text style={{ fontSize: 24 }}>{g.icon}</Text>
                </View>
                <View style={styles.goalInfo}>
                  <Text style={styles.goalName}>{g.name}</Text>
                  {g.target_date && (
                    <Text style={styles.goalDate}>Target: {g.target_date}</Text>
                  )}
                </View>
                {completed && <Text style={{ fontSize: 20 }}>🏆</Text>}
              </View>
              <View style={styles.goalAmounts}>
                <Text style={styles.goalSaved}>{formatCompact(g.current_amount)}</Text>
                <Text style={styles.goalTarget}>of {formatCompact(g.target_amount)}</Text>
                <Text style={[styles.goalPct, { color: g.color }]}>{Math.round(pct)}%</Text>
              </View>
              <ProgressBar pct={pct} color={g.color} />
              {!completed && (
                <Text style={styles.goalRemaining}>
                  {formatCompact(g.target_amount - g.current_amount)} more to go
                </Text>
              )}
            </TouchableOpacity>
          );
        })
      }

      <Text style={styles.hint}>Tap a goal to add money · Long press to delete</Text>
      <View style={{ height: 120 }} />

      {/* Add Goal */}
      <BottomSheet visible={showAdd} onClose={() => setShowAdd(false)} title="New Goal">
        <Field label="Goal Name">
          <TextInput
            style={styles.input}
            value={name}
            onChangeText={setName}
            placeholder="e.g. New Laptop, Vacation..."
            placeholderTextColor={Colors.text3}
          />
        </Field>
        <Field label="Target Amount (₹)">
          <TextInput
            style={styles.input}
            value={target}
            onChangeText={setTarget}
            keyboardType="numeric"
            placeholder="e.g. 50000"
            placeholderTextColor={Colors.text3}
          />
        </Field>
        <Field label="Target Date (optional)">
          <TextInput
            style={styles.input}
            value={targetDate}
            onChangeText={setTargetDate}
            placeholder="YYYY-MM-DD"
            placeholderTextColor={Colors.text3}
          />
        </Field>
        <Field label="Icon">
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {GOAL_ICONS.map(ic => (
              <TouchableOpacity
                key={ic}
                style={[styles.iconPill, selIcon === ic && styles.iconPillActive]}
                onPress={() => setSelIcon(ic)}
              >
                <Text style={{ fontSize: 22 }}>{ic}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Field>
        <Field label="Color">
          <View style={{ flexDirection: 'row', gap: 10 }}>
            {GOAL_COLORS.map(c => (
              <TouchableOpacity
                key={c}
                style={[styles.colorDot, { backgroundColor: c }, selColor === c && styles.colorDotActive]}
                onPress={() => setSelColor(c)}
              />
            ))}
          </View>
        </Field>
        <PrimaryButton label="Create Goal" onPress={handleAdd} />
      </BottomSheet>

      {/* Contribute */}
      {showContrib && (
        <BottomSheet visible onClose={() => setShowContrib(null)} title={`Add to ${showContrib.name}`}>
          <Field label="Amount (₹)">
            <TextInput
              style={styles.input}
              value={contribAmt}
              onChangeText={setContribAmt}
              keyboardType="numeric"
              placeholder="How much to add?"
              placeholderTextColor={Colors.text3}
            />
          </Field>
          <Text style={styles.contribInfo}>
            Current: {formatCompact(showContrib.current_amount)} / {formatCompact(showContrib.target_amount)}
          </Text>
          <PrimaryButton label="Add to Goal" onPress={handleContrib} />
        </BottomSheet>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  summaryCard: { margin: Spacing.lg },
  summaryLabel: { fontSize: FontSize.xs, color: Colors.text2, marginBottom: 4 },
  summaryAmt: { fontSize: FontSize.xxl, fontWeight: '700', color: Colors.text, marginBottom: Spacing.sm },
  summaryOf: { fontSize: FontSize.lg, color: Colors.text2, fontWeight: '400' },
  goalCard: {
    backgroundColor: Colors.bg2, borderRadius: BorderRadius.lg,
    borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.lg, marginHorizontal: Spacing.lg, marginBottom: Spacing.sm,
  },
  goalHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: Spacing.md, gap: Spacing.md },
  goalIcon: { width: 48, height: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  goalInfo: { flex: 1 },
  goalName: { fontSize: FontSize.lg, fontWeight: '600', color: Colors.text },
  goalDate: { fontSize: FontSize.xs, color: Colors.text2, marginTop: 2 },
  goalAmounts: { flexDirection: 'row', alignItems: 'baseline', gap: 6, marginBottom: 4 },
  goalSaved: { fontSize: FontSize.xl, fontWeight: '700', color: Colors.text },
  goalTarget: { fontSize: FontSize.sm, color: Colors.text2, flex: 1 },
  goalPct: { fontSize: FontSize.md, fontWeight: '700' },
  goalRemaining: { fontSize: FontSize.xs, color: Colors.text3, marginTop: 4 },
  hint: { textAlign: 'center', fontSize: FontSize.xs, color: Colors.text3, marginTop: 8 },
  input: {
    backgroundColor: Colors.bg3, borderRadius: BorderRadius.md,
    borderWidth: 1, borderColor: Colors.border2,
    padding: Spacing.md, color: Colors.text, fontSize: FontSize.md,
  },
  iconPill: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: Colors.bg3, borderWidth: 1, borderColor: Colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
  iconPillActive: { borderColor: Colors.accent, backgroundColor: Colors.accentLight },
  colorDot: { width: 32, height: 32, borderRadius: 16 },
  colorDotActive: { borderWidth: 3, borderColor: Colors.text },
  contribInfo: { fontSize: FontSize.sm, color: Colors.text2, marginBottom: Spacing.lg, textAlign: 'center' },
});
