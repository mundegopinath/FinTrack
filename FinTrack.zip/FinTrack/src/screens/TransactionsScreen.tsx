// src/screens/TransactionsScreen.tsx
import React, { useState, useCallback } from 'react';
import {
  View, Text, SectionList, StyleSheet, TextInput,
  ScrollView, TouchableOpacity, Alert
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getTransactions, deleteTransaction } from '../database/db';
import { TxItem, FilterChip, EmptyState } from '../components/UIComponents';
import { Colors, Spacing, FontSize, BorderRadius } from '../constants/theme';
import { getCategoryInfo, groupByDate } from '../utils/helpers';

const FILTERS = [
  { id: 'all', label: 'All' },
  { id: 'income', label: 'Income' },
  { id: 'expense', label: 'Expense' },
  { id: 'food', label: '🍜 Food' },
  { id: 'transport', label: '🚗 Travel' },
  { id: 'shopping', label: '🛍️ Shopping' },
  { id: 'bills', label: '⚡ Bills' },
  { id: 'salary', label: '💼 Salary' },
];

export default function TransactionsScreen({ navigation }: any) {
  const [transactions, setTransactions] = useState<any[]>([]);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    const filters: any = {};
    if (filter === 'income' || filter === 'expense') filters.type = filter;
    else if (filter !== 'all') filters.category = filter;
    if (search) filters.search = search;

    const txs = await getTransactions(filters);
    setTransactions(txs.map(t => {
      const cat = getCategoryInfo(t.category, t.type);
      return { ...t, icon: cat.icon, color: cat.color, categoryLabel: cat.label };
    }));
  }, [filter, search]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const handleDelete = (tx: any) => {
    Alert.alert('Delete Transaction', 'Are you sure you want to delete this?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete', style: 'destructive',
        onPress: async () => { await deleteTransaction(tx.id); load(); }
      }
    ]);
  };

  const grouped = groupByDate(transactions);
  const sections = grouped.map(([date, data]) => ({ title: date, data }));

  return (
    <View style={styles.container}>
      {/* Search */}
      <View style={styles.searchWrap}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.searchInput}
          value={search}
          onChangeText={s => { setSearch(s); }}
          onSubmitEditing={load}
          placeholder="Search transactions..."
          placeholderTextColor={Colors.text3}
          returnKeyType="search"
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => { setSearch(''); }}>
            <Text style={{ fontSize: 18, color: Colors.text3 }}>✕</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Filters */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filterRow}
        style={styles.filterScroll}
      >
        {FILTERS.map(f => (
          <FilterChip
            key={f.id}
            label={f.label}
            active={filter === f.id}
            onPress={() => setFilter(f.id)}
          />
        ))}
      </ScrollView>

      {/* TX List */}
      {sections.length === 0
        ? <EmptyState icon="🔍" title="No transactions found" subtitle="Try changing your filters" />
        : (
          <SectionList
            sections={sections}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            renderSectionHeader={({ section: { title } }) => (
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionLabel}>{title}</Text>
                <View style={styles.sectionLine} />
              </View>
            )}
            renderItem={({ item }) => (
              <TxItem
                tx={item}
                onPress={() => navigation.navigate('TransactionDetail', { tx: item })}
                onLongPress={() => handleDelete(item)}
              />
            )}
          />
        )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: Spacing.lg,
    backgroundColor: Colors.bg2,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: Spacing.md,
  },
  searchIcon: { fontSize: 16, marginRight: Spacing.sm },
  searchInput: {
    flex: 1,
    paddingVertical: Spacing.md,
    color: Colors.text,
    fontSize: FontSize.md,
  },
  filterScroll: { flexGrow: 0 },
  filterRow: { paddingHorizontal: Spacing.lg, paddingBottom: Spacing.sm },
  listContent: { paddingHorizontal: Spacing.lg, paddingBottom: 120 },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
    backgroundColor: Colors.bg,
  },
  sectionLabel: {
    fontSize: FontSize.xs,
    color: Colors.text3,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginRight: Spacing.sm,
    width: 70,
  },
  sectionLine: { flex: 1, height: 1, backgroundColor: Colors.border },
});
