// src/screens/BudgetsScreen.tsx
import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  TextInput, Alert
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import {
  getBudgets, upsertBudget, deleteBudget, getTransactions
} from '../database/db';
import {
  Card, SectionHeader, ProgressBar, EmptyState,
  BottomSheet, PrimaryButton, Field
} from '../components/UIComponents';
import { Colors, Spacing, FontSize, BorderRadius, CATEGORIES_EXPENSE } from '../constants/theme';
import { currentMonth, currentMonthLabel, formatCompact, getBudgetStatus, generateId } from '../utils/helpers';

export default function BudgetsScreen() {
  const [budgets, setBudgets] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [selCategory, setSelCategory] = useState('food');
  const [limitInput, setLimitInput] = useState('');
  const [notifyPct, setNotifyPct] = useState('80');

  const load = useCallback(async () => {
    const month = currentMonth();
    const [buds, txs] = await Promise.all([
      getBudgets(month),
      getTransactions({ type: 'expense', startDate: `${month}-01`, endDate: `${month}-31` }),
    ]);

    const enriched = buds.map(b => {
      const cat = CATEGORIES_EXPENSE.find(c => c.label === b.category || c.id === b.category.toLowerCase()) ?? { icon: '💰', color: '#8395a7', id: b.category };
      const spent = txs
        .filter(t => t.category === cat.id || t.category === b.category.toLowerCase())
        .reduce((s, t) => s + t.amount, 0);
      const status = getBudgetStatus(spent, b.monthly_limit);
      return { ...b, ...cat, spent, ...status };
    });

    setBudgets(enriched);
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const handleSave = async () => {
    const limit = parseFloat(limitInput);
    if (!limit || limit <= 0) { Alert.alert('Error', 'Enter a valid limit'); return; }
    const cat = CATEGORIES_EXPENSE.find(c => c.id === selCategory);
    await upsertBudget({
      id: generateId(),
      category: cat?.label ?? selCategory,
      monthly_limit: limit,
      month: currentMonth(),
      notify_at: parseInt(notifyPct) || 80,
    });
    setShowAdd(false);
    setLimitInput('');
    load();
  };

  const handleDelete = (id: string, name: string) => {
    Alert.alert('Delete Budget', `Remove "${name}" budget?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => { await deleteBudget(id); load(); } }
    ]);
  };

  const totalBudget = budgets.reduce((s, b) => s + b.monthly_limit, 0);
  const totalSpent = budgets.reduce((s, b) => s + b.spent, 0);

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Summary */}
      <Card style={styles.summaryCard}>
        <Text style={styles.summaryMonth}>{currentMonthLabel()}</Text>
        <View style={styles.summaryRow}>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Total Budget</Text>
            <Text style={styles.summaryVal}>{formatCompact(totalBudget)}</Text>
          </View>
          <View style={styles.summaryDivider} />
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Total Spent</Text>
            <Text style={[styles.summaryVal, { color: Colors.red }]}>{formatCompact(totalSpent)}</Text>
          </View>
          <View style={styles.summaryDivider} />
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Remaining</Text>
            <Text style={[styles.summaryVal, { color: Colors.green }]}>{formatCompact(Math.max(0, totalBudget - totalSpent))}</Text>
          </View>
        </View>
        {totalBudget > 0 && (
          <View style={{ marginTop: Spacing.md }}>
            <ProgressBar pct={(totalSpent / totalBudget) * 100} color={getBudgetStatus(totalSpent, totalBudget).color} />
          </View>
        )}
      </Card>

      <SectionHeader
        title="Category Budgets"
        action="+ Add Budget"
        onAction={() => setShowAdd(true)}
      />

      {budgets.length === 0
        ? <EmptyState icon="🎯" title="No budgets set" subtitle="Tap '+ Add Budget' to set spending limits" />
        : budgets.map(b => (
          <Card key={b.id} style={styles.budgetCard}>
            <View style={styles.budgetHeader}>
              <View style={styles.budgetLeft}>
                <View style={[styles.budgetIconWrap, { backgroundColor: b.color + '22' }]}>
                  <Text style={{ fontSize: 20 }}>{b.icon}</Text>
                </View>
                <View>
                  <Text style={styles.budgetName}>{b.category}</Text>
                  {b.pct >= 80 && (
                    <Text style={[styles.warnText, { color: b.pct >= 100 ? Colors.red : Colors.amber }]}>
                      {b.pct >= 100 ? '🚨 Exceeded!' : `⚠️ ${Math.round(b.pct)}% used`}
                    </Text>
                  )}
                </View>
              </View>
              <TouchableOpacity onPress={() => handleDelete(b.id, b.category)}>
                <Text style={{ color: Colors.text3, fontSize: 18 }}>✕</Text>
              </TouchableOpacity>
            </View>
            <ProgressBar pct={b.pct} color={b.color} />
            <View style={styles.budgetFooter}>
              <Text style={styles.budgetSub}>Spent: <Text style={{ color: Colors.text }}>{formatCompact(b.spent)}</Text></Text>
              <Text style={styles.budgetSub}>Limit: <Text style={{ color: Colors.text }}>{formatCompact(b.monthly_limit)}</Text></Text>
              <Text style={[styles.budgetSub, { color: b.pct >= 100 ? Colors.red : Colors.green }]}>
                {b.pct >= 100 ? `Over by ${formatCompact(b.spent - b.monthly_limit)}` : `${formatCompact(b.monthly_limit - b.spent)} left`}
              </Text>
            </View>
          </Card>
        ))
      }

      <View style={{ height: 120 }} />

      {/* Add Budget Sheet */}
      <BottomSheet visible={showAdd} onClose={() => setShowAdd(false)} title="Set Budget">
        <Field label="Category">
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={{ flexDirection: 'row', gap: 8, paddingBottom: 8 }}>
              {CATEGORIES_EXPENSE.map(c => (
                <TouchableOpacity
                  key={c.id}
                  style={[styles.catPill, selCategory === c.id && styles.catPillActive]}
                  onPress={() => setSelCategory(c.id)}
                >
                  <Text>{c.icon} {c.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </Field>
        <Field label="Monthly Limit (₹)">
          <TextInput
            style={styles.input}
            value={limitInput}
            onChangeText={setLimitInput}
            keyboardType="numeric"
            placeholder="e.g. 5000"
            placeholderTextColor={Colors.text3}
          />
        </Field>
        <Field label="Warn me when spent (%)">
          <TextInput
            style={styles.input}
            value={notifyPct}
            onChangeText={setNotifyPct}
            keyboardType="numeric"
            placeholder="80"
            placeholderTextColor={Colors.text3}
          />
        </Field>
        <PrimaryButton label="Save Budget" onPress={handleSave} />
      </BottomSheet>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  summaryCard: { margin: Spacing.lg, padding: Spacing.xl },
  summaryMonth: { fontSize: FontSize.md, fontWeight: '600', color: Colors.text, marginBottom: Spacing.lg },
  summaryRow: { flexDirection: 'row' },
  summaryItem: { flex: 1, alignItems: 'center' },
  summaryDivider: { width: 1, backgroundColor: Colors.border },
  summaryLabel: { fontSize: FontSize.xs, color: Colors.text2, marginBottom: 4 },
  summaryVal: { fontSize: FontSize.lg, fontWeight: '700', color: Colors.text },
  budgetCard: { marginHorizontal: Spacing.lg, marginBottom: Spacing.sm },
  budgetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.sm },
  budgetLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  budgetIconWrap: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  budgetName: { fontSize: FontSize.md, fontWeight: '600', color: Colors.text },
  warnText: { fontSize: FontSize.xs, marginTop: 2 },
  budgetFooter: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 },
  budgetSub: { fontSize: FontSize.xs, color: Colors.text2 },
  catPill: {
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    backgroundColor: Colors.bg3, borderRadius: BorderRadius.full,
    borderWidth: 1, borderColor: Colors.border,
  },
  catPillActive: { borderColor: Colors.accent, backgroundColor: Colors.accentLight },
  input: {
    backgroundColor: Colors.bg3, borderRadius: BorderRadius.md,
    borderWidth: 1, borderColor: Colors.border2,
    padding: Spacing.md, color: Colors.text, fontSize: FontSize.md,
  },
});
