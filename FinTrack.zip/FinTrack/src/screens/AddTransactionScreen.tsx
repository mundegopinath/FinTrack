// src/screens/AddTransactionScreen.tsx
import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TextInput, TouchableOpacity,
  Alert, KeyboardAvoidingView, Platform
} from 'react-native';
import { format } from 'date-fns';
import * as Haptics from 'expo-haptics';
import {
  createTransaction, getAccounts, getBudgets, Account
} from '../database/db';
import {
  TypeToggle, AmountInput, Field, CategoryChip, PrimaryButton,
  BottomSheet
} from '../components/UIComponents';
import {
  Colors, Spacing, BorderRadius, FontSize,
  CATEGORIES_EXPENSE, CATEGORIES_INCOME, RECURRENCE_OPTIONS
} from '../constants/theme';
import { generateId, currentMonth, getCategoryInfo } from '../utils/helpers';
import { sendBudgetAlert } from '../utils/notifications';

export default function AddTransactionScreen({ navigation, route }: any) {
  const editTx = route?.params?.tx;

  const [type, setType] = useState<'expense' | 'income' | 'transfer'>(editTx?.type ?? 'expense');
  const [amount, setAmount] = useState(editTx?.amount?.toString() ?? '');
  const [category, setCategory] = useState(editTx?.category ?? 'food');
  const [date, setDate] = useState(editTx?.date ?? format(new Date(), 'yyyy-MM-dd'));
  const [account, setAccount] = useState(editTx?.account_id ?? '');
  const [toAccount, setToAccount] = useState(editTx?.to_account_id ?? '');
  const [notes, setNotes] = useState(editTx?.notes ?? '');
  const [recurrence, setRecurrence] = useState(editTx?.recurrence ?? 'none');
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [showAccPicker, setShowAccPicker] = useState(false);
  const [showToAccPicker, setShowToAccPicker] = useState(false);
  const [showRecurPicker, setShowRecurPicker] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    getAccounts().then(accs => {
      setAccounts(accs);
      if (!account && accs.length > 0) {
        const def = accs.find(a => a.is_default) ?? accs[0];
        setAccount(def.id);
      }
    });
  }, []);

  const cats = type === 'income' ? CATEGORIES_INCOME : CATEGORIES_EXPENSE;

  const save = async () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) { Alert.alert('Error', 'Please enter a valid amount'); return; }
    if (!account) { Alert.alert('Error', 'Please select an account'); return; }
    if (type === 'transfer' && !toAccount) { Alert.alert('Error', 'Please select destination account'); return; }

    setSaving(true);
    try {
      await createTransaction({
        id: editTx?.id ?? generateId(),
        type,
        amount: amt,
        category,
        account_id: account,
        to_account_id: type === 'transfer' ? toAccount : undefined,
        date,
        notes,
        is_recurring: recurrence !== 'none' ? 1 : 0,
        recurrence,
      });

      // Check budget alerts
      if (type === 'expense') {
        const budgets = await getBudgets(currentMonth());
        const bud = budgets.find(b => b.category.toLowerCase() === category);
        if (bud) {
          // (In production, sum actual spending from DB)
          const pct = (amt / bud.monthly_limit) * 100;
          if (pct >= 80) await sendBudgetAlert(bud.category, pct);
        }
      }

      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      navigation.goBack();
    } catch (e) {
      Alert.alert('Error', 'Failed to save transaction');
    } finally {
      setSaving(false);
    }
  };

  const selAcc = accounts.find(a => a.id === account);
  const selToAcc = accounts.find(a => a.id === toAccount);

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.form}>

          <TypeToggle value={type} onChange={(t: any) => { setType(t); setCategory(t === 'income' ? 'salary' : 'food'); }} />

          <AmountInput value={amount} onChange={setAmount} />

          {type !== 'transfer' && (
            <Field label="Category">
              <View style={styles.catGrid}>
                {cats.map(c => (
                  <CategoryChip
                    key={c.id}
                    cat={c}
                    selected={category === c.id}
                    onPress={() => setCategory(c.id)}
                  />
                ))}
              </View>
            </Field>
          )}

          <Field label="Date">
            <TextInput
              style={styles.input}
              value={date}
              onChangeText={setDate}
              placeholder="YYYY-MM-DD"
              placeholderTextColor={Colors.text3}
            />
          </Field>

          <Field label={type === 'transfer' ? 'From Account' : 'Account'}>
            <TouchableOpacity style={styles.picker} onPress={() => setShowAccPicker(true)}>
              <Text style={styles.pickerText}>
                {selAcc ? `${selAcc.icon} ${selAcc.name}` : 'Select account'}
              </Text>
              <Text style={styles.pickerArrow}>›</Text>
            </TouchableOpacity>
          </Field>

          {type === 'transfer' && (
            <Field label="To Account">
              <TouchableOpacity style={styles.picker} onPress={() => setShowToAccPicker(true)}>
                <Text style={styles.pickerText}>
                  {selToAcc ? `${selToAcc.icon} ${selToAcc.name}` : 'Select account'}
                </Text>
                <Text style={styles.pickerArrow}>›</Text>
              </TouchableOpacity>
            </Field>
          )}

          <Field label="Notes (Optional)">
            <TextInput
              style={styles.input}
              value={notes}
              onChangeText={setNotes}
              placeholder="Add a note..."
              placeholderTextColor={Colors.text3}
              multiline
            />
          </Field>

          <Field label="Repeat">
            <TouchableOpacity style={styles.picker} onPress={() => setShowRecurPicker(true)}>
              <Text style={styles.pickerText}>
                {RECURRENCE_OPTIONS.find(r => r.id === recurrence)?.label ?? 'None'}
              </Text>
              <Text style={styles.pickerArrow}>›</Text>
            </TouchableOpacity>
          </Field>

          <PrimaryButton
            label={editTx ? 'Update Transaction' : 'Save Transaction'}
            onPress={save}
            loading={saving}
            style={{ marginTop: 8 }}
          />
        </View>
        <View style={{ height: 120 }} />
      </ScrollView>

      {/* Account Picker */}
      <BottomSheet visible={showAccPicker} onClose={() => setShowAccPicker(false)} title="Select Account">
        {accounts.map(a => (
          <TouchableOpacity
            key={a.id}
            style={[styles.option, account === a.id && styles.optionSelected]}
            onPress={() => { setAccount(a.id); setShowAccPicker(false); }}
          >
            <Text style={styles.optionText}>{a.icon} {a.name}</Text>
            <Text style={[styles.optionSub, { color: a.balance < 0 ? Colors.red : Colors.green }]}>
              ₹{Math.abs(a.balance).toLocaleString('en-IN')}
            </Text>
          </TouchableOpacity>
        ))}
      </BottomSheet>

      {/* To Account Picker */}
      <BottomSheet visible={showToAccPicker} onClose={() => setShowToAccPicker(false)} title="To Account">
        {accounts.filter(a => a.id !== account).map(a => (
          <TouchableOpacity
            key={a.id}
            style={[styles.option, toAccount === a.id && styles.optionSelected]}
            onPress={() => { setToAccount(a.id); setShowToAccPicker(false); }}
          >
            <Text style={styles.optionText}>{a.icon} {a.name}</Text>
          </TouchableOpacity>
        ))}
      </BottomSheet>

      {/* Recurrence Picker */}
      <BottomSheet visible={showRecurPicker} onClose={() => setShowRecurPicker(false)} title="Repeat">
        {RECURRENCE_OPTIONS.map(r => (
          <TouchableOpacity
            key={r.id}
            style={[styles.option, recurrence === r.id && styles.optionSelected]}
            onPress={() => { setRecurrence(r.id); setShowRecurPicker(false); }}
          >
            <Text style={styles.optionText}>{r.label}</Text>
            {recurrence === r.id && <Text style={{ color: Colors.accent }}>✓</Text>}
          </TouchableOpacity>
        ))}
      </BottomSheet>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  form: { padding: Spacing.lg, paddingTop: Spacing.xl },
  catGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  input: {
    backgroundColor: Colors.bg3,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    borderColor: Colors.border2,
    padding: Spacing.md,
    color: Colors.text,
    fontSize: FontSize.md,
  },
  picker: {
    backgroundColor: Colors.bg3,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    borderColor: Colors.border2,
    padding: Spacing.md,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pickerText: { fontSize: FontSize.md, color: Colors.text },
  pickerArrow: { fontSize: 20, color: Colors.text3 },
  option: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  optionSelected: { backgroundColor: Colors.accentLight, borderRadius: BorderRadius.sm },
  optionText: { fontSize: FontSize.md, color: Colors.text },
  optionSub: { fontSize: FontSize.sm, fontWeight: '700' },
});
