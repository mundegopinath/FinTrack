// src/navigation/AppNavigator.tsx
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import DashboardScreen from '../screens/DashboardScreen';
import TransactionsScreen from '../screens/TransactionsScreen';
import AddTransactionScreen from '../screens/AddTransactionScreen';
import BudgetsScreen from '../screens/BudgetsScreen';
import AccountsScreen from '../screens/AccountsScreen';
import ReportsScreen from '../screens/ReportsScreen';
import GoalsScreen from '../screens/GoalsScreen';
import SettingsScreen from '../screens/SettingsScreen';

import { Colors, Spacing, BorderRadius, FontSize } from '../constants/theme';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const TAB_ICONS: Record<string, string> = {
  Dashboard: '📊',
  Transactions: '📋',
  Add: '+',
  Budgets: '🎯',
  More: '⋯',
};

function CustomTabBar({ state, descriptors, navigation }: any) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.tabBar, { paddingBottom: insets.bottom || 8 }]}>
      {state.routes.map((route: any, index: number) => {
        const { options } = descriptors[route.key];
        const isFocused = state.index === index;
        const isAdd = route.name === 'Add';

        const onPress = () => {
          const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        if (isAdd) {
          return (
            <TouchableOpacity key={route.key} style={styles.addTab} onPress={onPress} activeOpacity={0.85}>
              <View style={styles.addButton}>
                <Text style={styles.addIcon}>+</Text>
              </View>
            </TouchableOpacity>
          );
        }

        return (
          <TouchableOpacity
            key={route.key}
            style={styles.tabItem}
            onPress={onPress}
            activeOpacity={0.7}
          >
            <Text style={[styles.tabIcon, isFocused && styles.tabIconActive]}>
              {TAB_ICONS[route.name] ?? '○'}
            </Text>
            <Text style={[styles.tabLabel, isFocused && styles.tabLabelActive]}>
              {route.name}
            </Text>
            {isFocused && <View style={styles.tabDot} />}
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

function MoreStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: Colors.bg2, borderBottomColor: Colors.border },
        headerTintColor: Colors.text,
        headerTitleStyle: { fontWeight: '700' },
        cardStyle: { backgroundColor: Colors.bg },
      }}
    >
      <Stack.Screen name="MoreHome" component={MoreHomeScreen} options={{ title: 'More' }} />
      <Stack.Screen name="Reports" component={ReportsScreen} options={{ title: 'Reports & Insights' }} />
      <Stack.Screen name="Goals" component={GoalsScreen} options={{ title: 'Financial Goals' }} />
      <Stack.Screen name="Settings" component={SettingsScreen} options={{ title: 'Settings' }} />
    </Stack.Navigator>
  );
}

function MoreHomeScreen({ navigation }: any) {
  const items = [
    { icon: '📈', label: 'Reports & Insights', sub: 'Monthly analysis', screen: 'Reports', color: Colors.greenLight },
    { icon: '🏆', label: 'Financial Goals', sub: 'Track your savings goals', screen: 'Goals', color: Colors.amberLight },
    { icon: '⚙️', label: 'Settings', sub: 'Preferences & data export', screen: 'Settings', color: Colors.accentLight },
  ];
  return (
    <View style={{ flex: 1, backgroundColor: Colors.bg, padding: Spacing.lg }}>
      {items.map(item => (
        <TouchableOpacity
          key={item.screen}
          style={styles.moreItem}
          onPress={() => navigation.navigate(item.screen)}
          activeOpacity={0.8}
        >
          <View style={[styles.moreIcon, { backgroundColor: item.color }]}>
            <Text style={{ fontSize: 24 }}>{item.icon}</Text>
          </View>
          <View style={styles.moreInfo}>
            <Text style={styles.moreLabel}>{item.label}</Text>
            <Text style={styles.moreSub}>{item.sub}</Text>
          </View>
          <Text style={{ fontSize: 20, color: Colors.text3 }}>›</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

function DashboardStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: Colors.bg, elevation: 0, shadowOpacity: 0 },
        headerTintColor: Colors.text,
        headerTitleStyle: { fontWeight: '700' },
        cardStyle: { backgroundColor: Colors.bg },
      }}
    >
      <Stack.Screen name="DashboardHome" component={DashboardScreen} options={{ headerShown: false }} />
      <Stack.Screen name="TransactionDetail" component={TransactionDetailScreen} options={{ title: 'Transaction' }} />
      <Stack.Screen name="Transactions" component={TransactionsScreen} options={{ title: 'All Transactions' }} />
    </Stack.Navigator>
  );
}

function TransactionDetailScreen({ route, navigation }: any) {
  const { tx } = route.params;
  const isInc = tx.type === 'income';
  return (
    <View style={{ flex: 1, backgroundColor: Colors.bg, padding: Spacing.lg }}>
      <View style={styles.detailCard}>
        <View style={[styles.detailIcon, { backgroundColor: (tx.color ?? Colors.accent) + '22' }]}>
          <Text style={{ fontSize: 36 }}>{tx.icon ?? '💰'}</Text>
        </View>
        <Text style={styles.detailCategory}>{tx.categoryLabel ?? tx.category}</Text>
        <Text style={[styles.detailAmount, { color: isInc ? Colors.green : Colors.red }]}>
          {isInc ? '+' : '-'}₹{Math.abs(tx.amount).toLocaleString('en-IN')}
        </Text>
        <View style={styles.detailRows}>
          {[
            ['Date', tx.date],
            ['Account', tx.account_name ?? tx.account_id],
            ['Type', tx.type.charAt(0).toUpperCase() + tx.type.slice(1)],
            tx.notes ? ['Notes', tx.notes] : null,
            tx.recurrence && tx.recurrence !== 'none' ? ['Recurring', tx.recurrence] : null,
          ].filter(Boolean).map(([label, value]: any) => (
            <View key={label} style={styles.detailRow}>
              <Text style={styles.detailRowLabel}>{label}</Text>
              <Text style={styles.detailRowVal}>{value}</Text>
            </View>
          ))}
        </View>
      </View>
      <TouchableOpacity
        style={styles.editBtn}
        onPress={() => navigation.navigate('Add', { screen: 'AddHome', params: { tx } })}
      >
        <Text style={styles.editBtnText}>Edit Transaction</Text>
      </TouchableOpacity>
    </View>
  );
}

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        tabBar={props => <CustomTabBar {...props} />}
        screenOptions={{
          headerStyle: { backgroundColor: Colors.bg2, elevation: 0, shadowOpacity: 0, borderBottomWidth: 1, borderBottomColor: Colors.border },
          headerTintColor: Colors.text,
          headerTitleStyle: { fontWeight: '700', fontSize: FontSize.lg },
        }}
      >
        <Tab.Screen name="Dashboard" component={DashboardStack} options={{ headerShown: false }} />
        <Tab.Screen name="Transactions" component={TransactionsScreen} />
        <Tab.Screen name="Add" component={AddTransactionScreen} options={{ title: 'New Entry' }} />
        <Tab.Screen name="Budgets" component={BudgetsScreen} />
        <Tab.Screen name="More" component={MoreStack} options={{ headerShown: false }} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    flexDirection: 'row',
    backgroundColor: Colors.bg2,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingTop: 8,
    elevation: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  tabItem: { flex: 1, alignItems: 'center', paddingBottom: 4, position: 'relative' },
  tabIcon: { fontSize: 22, color: Colors.text3 },
  tabIconActive: { color: Colors.accent },
  tabLabel: { fontSize: 10, color: Colors.text3, marginTop: 2 },
  tabLabelActive: { color: Colors.accent, fontWeight: '600' },
  tabDot: {
    position: 'absolute', bottom: 0, width: 4, height: 4,
    borderRadius: 2, backgroundColor: Colors.accent,
  },
  addTab: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  addButton: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: Colors.accent,
    alignItems: 'center', justifyContent: 'center',
    marginTop: -20,
    elevation: 8,
    shadowColor: Colors.accent,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
  },
  addIcon: { fontSize: 28, color: '#fff', fontWeight: '300', lineHeight: 32 },
  moreItem: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.bg2, borderRadius: BorderRadius.lg,
    borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.lg, marginBottom: Spacing.md,
  },
  moreIcon: {
    width: 52, height: 52, borderRadius: 16,
    alignItems: 'center', justifyContent: 'center', marginRight: Spacing.md,
  },
  moreInfo: { flex: 1 },
  moreLabel: { fontSize: FontSize.lg, fontWeight: '600', color: Colors.text },
  moreSub: { fontSize: FontSize.sm, color: Colors.text2, marginTop: 2 },
  detailCard: {
    backgroundColor: Colors.bg2, borderRadius: BorderRadius.xl,
    borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.xxl, alignItems: 'center', marginBottom: Spacing.lg,
  },
  detailIcon: {
    width: 80, height: 80, borderRadius: 24,
    alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.md,
  },
  detailCategory: { fontSize: FontSize.lg, color: Colors.text2, marginBottom: 4 },
  detailAmount: { fontSize: 38, fontWeight: '700', marginBottom: Spacing.xxl },
  detailRows: { width: '100%' },
  detailRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingVertical: Spacing.sm, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  detailRowLabel: { fontSize: FontSize.sm, color: Colors.text2 },
  detailRowVal: { fontSize: FontSize.sm, fontWeight: '600', color: Colors.text },
  editBtn: {
    backgroundColor: Colors.bg3, borderRadius: BorderRadius.md,
    borderWidth: 1, borderColor: Colors.border2,
    padding: Spacing.lg, alignItems: 'center',
  },
  editBtnText: { fontSize: FontSize.md, color: Colors.text2, fontWeight: '500' },
});
