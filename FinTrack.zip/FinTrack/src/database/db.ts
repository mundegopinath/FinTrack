// src/database/db.ts
import * as SQLite from 'expo-sqlite';

let db: SQLite.SQLiteDatabase;

export const getDB = () => {
  if (!db) {
    db = SQLite.openDatabaseSync('fintrack.db');
  }
  return db;
};

export const initDatabase = async (): Promise<void> => {
  const database = getDB();

  await database.execAsync(`
    PRAGMA journal_mode = WAL;

    CREATE TABLE IF NOT EXISTS accounts (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      type TEXT NOT NULL,
      balance REAL DEFAULT 0,
      color TEXT DEFAULT '#6c63ff',
      icon TEXT DEFAULT '💳',
      is_default INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL CHECK(type IN ('income','expense','transfer')),
      amount REAL NOT NULL,
      category TEXT NOT NULL,
      account_id TEXT NOT NULL,
      to_account_id TEXT,
      date TEXT NOT NULL,
      notes TEXT DEFAULT '',
      is_recurring INTEGER DEFAULT 0,
      recurrence TEXT DEFAULT 'none',
      recurrence_end_date TEXT,
      parent_id TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(account_id) REFERENCES accounts(id)
    );

    CREATE TABLE IF NOT EXISTS budgets (
      id TEXT PRIMARY KEY,
      category TEXT NOT NULL UNIQUE,
      monthly_limit REAL NOT NULL,
      month TEXT NOT NULL,
      notify_at INTEGER DEFAULT 80,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS goals (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      target_amount REAL NOT NULL,
      current_amount REAL DEFAULT 0,
      target_date TEXT,
      icon TEXT DEFAULT '🎯',
      color TEXT DEFAULT '#6c63ff',
      account_id TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(account_id) REFERENCES accounts(id)
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date);
    CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type);
    CREATE INDEX IF NOT EXISTS idx_transactions_category ON transactions(category);
    CREATE INDEX IF NOT EXISTS idx_transactions_account ON transactions(account_id);
  `);

  // Seed default settings
  await database.runAsync(
    `INSERT OR IGNORE INTO settings (key, value) VALUES
      ('currency', '₹'),
      ('currency_code', 'INR'),
      ('dark_mode', '1'),
      ('notification_enabled', '1'),
      ('budget_notify_pct', '80'),
      ('onboarded', '0')`
  );

  // Seed default accounts if none exist
  const count = await database.getFirstAsync<{ count: number }>(
    'SELECT COUNT(*) as count FROM accounts'
  );
  if (count?.count === 0) {
    await database.execAsync(`
      INSERT INTO accounts (id, name, type, balance, color, icon, is_default) VALUES
        ('acc_cash', 'Cash', 'cash', 5000, '#00d4aa', '💵', 1),
        ('acc_bank', 'Bank Account', 'bank', 25000, '#6c63ff', '🏦', 0),
        ('acc_upi', 'UPI Wallet', 'upi', 2000, '#ffd93d', '📱', 0);
    `);
  }
};

// ─── ACCOUNTS ────────────────────────────────────────────────────────────────

export const getAccounts = async () => {
  const db = getDB();
  return db.getAllAsync<Account>('SELECT * FROM accounts ORDER BY is_default DESC, name ASC');
};

export const getAccount = async (id: string) => {
  const db = getDB();
  return db.getFirstAsync<Account>('SELECT * FROM accounts WHERE id = ?', [id]);
};

export const createAccount = async (account: Omit<Account, 'created_at' | 'updated_at'>) => {
  const db = getDB();
  await db.runAsync(
    `INSERT INTO accounts (id, name, type, balance, color, icon, is_default) VALUES (?,?,?,?,?,?,?)`,
    [account.id, account.name, account.type, account.balance, account.color, account.icon, account.is_default ? 1 : 0]
  );
};

export const updateAccountBalance = async (id: string, balance: number) => {
  const db = getDB();
  await db.runAsync(
    'UPDATE accounts SET balance = ?, updated_at = datetime("now") WHERE id = ?',
    [balance, id]
  );
};

export const deleteAccount = async (id: string) => {
  const db = getDB();
  await db.runAsync('DELETE FROM accounts WHERE id = ?', [id]);
};

// ─── TRANSACTIONS ─────────────────────────────────────────────────────────────

export const getTransactions = async (filters?: TransactionFilters) => {
  const db = getDB();
  let query = 'SELECT t.*, a.name as account_name, a.icon as account_icon FROM transactions t LEFT JOIN accounts a ON t.account_id = a.id WHERE 1=1';
  const params: any[] = [];

  if (filters?.type && filters.type !== 'all') {
    query += ' AND t.type = ?';
    params.push(filters.type);
  }
  if (filters?.category) {
    query += ' AND t.category = ?';
    params.push(filters.category);
  }
  if (filters?.accountId) {
    query += ' AND t.account_id = ?';
    params.push(filters.accountId);
  }
  if (filters?.startDate) {
    query += ' AND t.date >= ?';
    params.push(filters.startDate);
  }
  if (filters?.endDate) {
    query += ' AND t.date <= ?';
    params.push(filters.endDate);
  }
  if (filters?.search) {
    query += ' AND (t.notes LIKE ? OR t.category LIKE ?)';
    params.push(`%${filters.search}%`, `%${filters.search}%`);
  }

  query += ' ORDER BY t.date DESC, t.created_at DESC';

  if (filters?.limit) {
    query += ` LIMIT ${filters.limit}`;
  }

  return db.getAllAsync<Transaction>(query, params);
};

export const createTransaction = async (tx: Omit<Transaction, 'created_at'>) => {
  const db = getDB();
  await db.runAsync(
    `INSERT INTO transactions (id, type, amount, category, account_id, to_account_id, date, notes, is_recurring, recurrence, recurrence_end_date, parent_id)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    [tx.id, tx.type, tx.amount, tx.category, tx.account_id, tx.to_account_id ?? null,
     tx.date, tx.notes ?? '', tx.is_recurring ? 1 : 0, tx.recurrence ?? 'none',
     tx.recurrence_end_date ?? null, tx.parent_id ?? null]
  );

  // Update account balance
  if (tx.type === 'income') {
    await db.runAsync('UPDATE accounts SET balance = balance + ? WHERE id = ?', [tx.amount, tx.account_id]);
  } else if (tx.type === 'expense') {
    await db.runAsync('UPDATE accounts SET balance = balance - ? WHERE id = ?', [tx.amount, tx.account_id]);
  } else if (tx.type === 'transfer' && tx.to_account_id) {
    await db.runAsync('UPDATE accounts SET balance = balance - ? WHERE id = ?', [tx.amount, tx.account_id]);
    await db.runAsync('UPDATE accounts SET balance = balance + ? WHERE id = ?', [tx.amount, tx.to_account_id]);
  }
};

export const updateTransaction = async (tx: Transaction) => {
  const db = getDB();
  // Reverse old transaction effect
  const old = await db.getFirstAsync<Transaction>('SELECT * FROM transactions WHERE id = ?', [tx.id]);
  if (old) {
    if (old.type === 'income') await db.runAsync('UPDATE accounts SET balance = balance - ? WHERE id = ?', [old.amount, old.account_id]);
    else if (old.type === 'expense') await db.runAsync('UPDATE accounts SET balance = balance + ? WHERE id = ?', [old.amount, old.account_id]);
    else if (old.type === 'transfer' && old.to_account_id) {
      await db.runAsync('UPDATE accounts SET balance = balance + ? WHERE id = ?', [old.amount, old.account_id]);
      await db.runAsync('UPDATE accounts SET balance = balance - ? WHERE id = ?', [old.amount, old.to_account_id]);
    }
  }

  await db.runAsync(
    `UPDATE transactions SET type=?, amount=?, category=?, account_id=?, date=?, notes=? WHERE id=?`,
    [tx.type, tx.amount, tx.category, tx.account_id, tx.date, tx.notes ?? '', tx.id]
  );

  // Apply new effect
  if (tx.type === 'income') await db.runAsync('UPDATE accounts SET balance = balance + ? WHERE id = ?', [tx.amount, tx.account_id]);
  else if (tx.type === 'expense') await db.runAsync('UPDATE accounts SET balance = balance - ? WHERE id = ?', [tx.amount, tx.account_id]);
  else if (tx.type === 'transfer' && tx.to_account_id) {
    await db.runAsync('UPDATE accounts SET balance = balance - ? WHERE id = ?', [tx.amount, tx.account_id]);
    await db.runAsync('UPDATE accounts SET balance = balance + ? WHERE id = ?', [tx.amount, tx.to_account_id]);
  }
};

export const deleteTransaction = async (id: string) => {
  const db = getDB();
  const tx = await db.getFirstAsync<Transaction>('SELECT * FROM transactions WHERE id = ?', [id]);
  if (tx) {
    if (tx.type === 'income') await db.runAsync('UPDATE accounts SET balance = balance - ? WHERE id = ?', [tx.amount, tx.account_id]);
    else if (tx.type === 'expense') await db.runAsync('UPDATE accounts SET balance = balance + ? WHERE id = ?', [tx.amount, tx.account_id]);
    else if (tx.type === 'transfer' && tx.to_account_id) {
      await db.runAsync('UPDATE accounts SET balance = balance + ? WHERE id = ?', [tx.amount, tx.account_id]);
      await db.runAsync('UPDATE accounts SET balance = balance - ? WHERE id = ?', [tx.amount, tx.to_account_id]);
    }
    await db.runAsync('DELETE FROM transactions WHERE id = ?', [id]);
  }
};

// ─── BUDGETS ──────────────────────────────────────────────────────────────────

export const getBudgets = async (month: string) => {
  const db = getDB();
  return db.getAllAsync<Budget>('SELECT * FROM budgets WHERE month = ?', [month]);
};

export const upsertBudget = async (budget: Budget) => {
  const db = getDB();
  await db.runAsync(
    `INSERT INTO budgets (id, category, monthly_limit, month, notify_at) VALUES (?,?,?,?,?)
     ON CONFLICT(category) DO UPDATE SET monthly_limit=excluded.monthly_limit, notify_at=excluded.notify_at`,
    [budget.id, budget.category, budget.monthly_limit, budget.month, budget.notify_at ?? 80]
  );
};

export const deleteBudget = async (id: string) => {
  const db = getDB();
  await db.runAsync('DELETE FROM budgets WHERE id = ?', [id]);
};

// ─── GOALS ────────────────────────────────────────────────────────────────────

export const getGoals = async () => {
  const db = getDB();
  return db.getAllAsync<Goal>('SELECT * FROM goals ORDER BY created_at DESC');
};

export const createGoal = async (goal: Goal) => {
  const db = getDB();
  await db.runAsync(
    `INSERT INTO goals (id, name, target_amount, current_amount, target_date, icon, color, account_id)
     VALUES (?,?,?,?,?,?,?,?)`,
    [goal.id, goal.name, goal.target_amount, goal.current_amount, goal.target_date ?? null,
     goal.icon, goal.color, goal.account_id ?? null]
  );
};

export const updateGoalAmount = async (id: string, amount: number) => {
  const db = getDB();
  await db.runAsync('UPDATE goals SET current_amount = current_amount + ? WHERE id = ?', [amount, id]);
};

export const deleteGoal = async (id: string) => {
  const db = getDB();
  await db.runAsync('DELETE FROM goals WHERE id = ?', [id]);
};

// ─── SETTINGS ─────────────────────────────────────────────────────────────────

export const getSetting = async (key: string): Promise<string | null> => {
  const db = getDB();
  const row = await db.getFirstAsync<{ value: string }>('SELECT value FROM settings WHERE key = ?', [key]);
  return row?.value ?? null;
};

export const setSetting = async (key: string, value: string) => {
  const db = getDB();
  await db.runAsync('INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)', [key, value]);
};

// ─── ANALYTICS ────────────────────────────────────────────────────────────────

export const getMonthlyTotals = async (month: string) => {
  const db = getDB();
  const start = `${month}-01`;
  const end = `${month}-31`;
  const rows = await db.getAllAsync<{ type: string; total: number }>(
    `SELECT type, SUM(amount) as total FROM transactions WHERE date BETWEEN ? AND ? AND type != 'transfer' GROUP BY type`,
    [start, end]
  );
  const result = { income: 0, expense: 0 };
  rows.forEach(r => { if (r.type === 'income') result.income = r.total; else result.expense = r.total; });
  return result;
};

export const getCategoryBreakdown = async (month: string) => {
  const db = getDB();
  const start = `${month}-01`;
  const end = `${month}-31`;
  return db.getAllAsync<{ category: string; total: number }>(
    `SELECT category, SUM(amount) as total FROM transactions WHERE date BETWEEN ? AND ? AND type='expense' GROUP BY category ORDER BY total DESC`,
    [start, end]
  );
};

export const getLast6MonthsData = async () => {
  const db = getDB();
  return db.getAllAsync<{ month: string; type: string; total: number }>(
    `SELECT strftime('%Y-%m', date) as month, type, SUM(amount) as total
     FROM transactions WHERE type != 'transfer' AND date >= date('now', '-6 months')
     GROUP BY month, type ORDER BY month ASC`
  );
};

// ─── TYPES ────────────────────────────────────────────────────────────────────

export interface Account {
  id: string;
  name: string;
  type: string;
  balance: number;
  color: string;
  icon: string;
  is_default: number;
  created_at?: string;
  updated_at?: string;
}

export interface Transaction {
  id: string;
  type: 'income' | 'expense' | 'transfer';
  amount: number;
  category: string;
  account_id: string;
  to_account_id?: string;
  date: string;
  notes?: string;
  is_recurring?: number;
  recurrence?: string;
  recurrence_end_date?: string;
  parent_id?: string;
  created_at?: string;
  account_name?: string;
  account_icon?: string;
}

export interface Budget {
  id: string;
  category: string;
  monthly_limit: number;
  month: string;
  notify_at?: number;
  created_at?: string;
}

export interface Goal {
  id: string;
  name: string;
  target_amount: number;
  current_amount: number;
  target_date?: string;
  icon: string;
  color: string;
  account_id?: string;
  created_at?: string;
}

export interface TransactionFilters {
  type?: string;
  category?: string;
  accountId?: string;
  startDate?: string;
  endDate?: string;
  search?: string;
  limit?: number;
}
