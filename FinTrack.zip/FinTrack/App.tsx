// App.tsx
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';

import { initDatabase } from './src/database/db';
import AppNavigator from './src/navigation/AppNavigator';
import { Colors } from './src/constants/theme';
import { requestNotificationPermissions } from './src/utils/notifications';

export default function App() {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        await initDatabase();
        await requestNotificationPermissions();
        setReady(true);
      } catch (e: any) {
        setError(e?.message ?? 'Failed to initialize');
      }
    })();
  }, []);

  if (error) {
    return (
      <View style={styles.splash}>
        <Text style={styles.errorIcon}>⚠️</Text>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }

  if (!ready) {
    return (
      <View style={styles.splash}>
        <Text style={styles.splashIcon}>💜</Text>
        <Text style={styles.splashTitle}>FinTrack</Text>
        <Text style={styles.splashSub}>Your personal finance manager</Text>
        <ActivityIndicator color={Colors.accent} style={{ marginTop: 40 }} />
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar style="light" backgroundColor={Colors.bg} />
        <AppNavigator />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  splash: {
    flex: 1,
    backgroundColor: Colors.bg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  splashIcon: { fontSize: 64, marginBottom: 16 },
  splashTitle: {
    fontSize: 36,
    fontWeight: '700',
    color: Colors.text,
    letterSpacing: 1,
  },
  splashSub: { fontSize: 14, color: Colors.text2, marginTop: 8 },
  errorIcon: { fontSize: 48, marginBottom: 12 },
  errorText: { fontSize: 14, color: Colors.red, textAlign: 'center', padding: 20 },
});
