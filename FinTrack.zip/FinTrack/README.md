# 💜 FinTrack — Personal Finance Manager

A clean, offline-first personal finance app for Android built with **React Native (Expo)**.

---

## ✨ Features

| Feature | Details |
|---|---|
| 💸 Income & Expense Tracking | Add entries with category, account, date, notes |
| 💳 Account Management | Cash, Bank, UPI, Credit Card — with live balances |
| 🎯 Budget Management | Monthly category budgets with progress bars & alerts |
| 📊 Dashboard | Balance overview, pie chart, 6-month trend, recent transactions |
| 📋 Transaction History | Search, filter by type/category/account, delete |
| 📈 Reports & Insights | Spending breakdown, savings rate, monthly comparisons |
| 🏆 Financial Goals | Track savings targets with progress |
| 🔔 Notifications | Budget warnings + daily reminder to log expenses |
| 📤 Export | CSV export + full JSON backup via Android share sheet |
| 🔄 Recurring Transactions | Daily / weekly / monthly / yearly repeating entries |
| 💾 100% Offline | SQLite via expo-sqlite — no internet, no account needed |
| 🌙 Dark Mode | Beautiful dark theme (default) with light mode option |

---

## 🗂️ Project Structure

```
FinTrack/
├── App.tsx                          # Entry point — DB init + navigation
├── app.json                         # Expo config
├── eas.json                         # EAS Build config (APK/AAB)
├── package.json
├── tsconfig.json
└── src/
    ├── constants/
    │   └── theme.ts                 # Colors, spacing, categories, account types
    ├── database/
    │   └── db.ts                    # SQLite schema, all queries, TypeScript types
    ├── navigation/
    │   └── AppNavigator.tsx         # Bottom tab nav + stack navigators
    ├── components/
    │   └── UIComponents.tsx         # Reusable: Card, TxItem, BalanceCard, etc.
    ├── screens/
    │   ├── DashboardScreen.tsx      # Home: balance, charts, recent tx
    │   ├── TransactionsScreen.tsx   # History: search, filter, delete
    │   ├── AddTransactionScreen.tsx # Add/edit income, expense, transfer
    │   ├── BudgetsScreen.tsx        # Set & track monthly budgets
    │   ├── AccountsScreen.tsx       # Manage accounts, net worth
    │   ├── ReportsScreen.tsx        # Analytics, insights, charts
    │   ├── GoalsScreen.tsx          # Financial goals tracker
    │   └── SettingsScreen.tsx       # Notifications, export, about
    ├── hooks/
    │   └── useStore.ts              # Zustand global state
    └── utils/
        ├── helpers.ts               # Formatting, export, date utils
        └── notifications.ts         # Expo Notifications service
```

---

## 🚀 Getting Started

### Prerequisites

- **Node.js** 18+ — [nodejs.org](https://nodejs.org)
- **Expo CLI** — `npm install -g expo-cli`
- **EAS CLI** (for APK builds) — `npm install -g eas-cli`
- **Android Studio** (for emulator) or a physical Android device

### 1. Install Dependencies

```bash
cd FinTrack
npm install
```

### 2. Run in Development

```bash
# Start Expo dev server
npx expo start

# Then press 'a' to open on Android emulator
# Or scan QR code with Expo Go app on your phone
```

> **Expo Go** app: Install from Play Store → scan QR code → app runs instantly

---

## 📦 Build APK for Android

### Option A — EAS Cloud Build (Recommended, no Android Studio needed)

```bash
# Login to Expo account (free)
eas login

# Build APK
eas build --platform android --profile preview
```

This uploads to Expo's servers and emails you a download link for the `.apk` file. Takes ~5 minutes.

### Option B — Local Build (requires Android Studio + SDK)

```bash
# Generate native Android project
npx expo prebuild --platform android

# Build debug APK
cd android
./gradlew assembleDebug

# APK location:
# android/app/build/outputs/apk/debug/app-debug.apk
```

### Option C — Build Release APK Locally

```bash
npx expo prebuild --platform android

cd android

# Create keystore (first time only)
keytool -genkey -v -keystore fintrack.keystore -alias fintrack -keyalg RSA -keysize 2048 -validity 10000

# Build release
./gradlew assembleRelease

# APK location:
# android/app/build/outputs/apk/release/app-release.apk
```

---

## 🗄️ Database Schema

```sql
accounts         — id, name, type, balance, color, icon, is_default
transactions     — id, type, amount, category, account_id, date, notes, recurrence
budgets          — id, category, monthly_limit, month, notify_at
goals            — id, name, target_amount, current_amount, target_date, icon, color
settings         — key, value (currency, dark_mode, notifications...)
```

All data is stored in **SQLite** at the app's private storage path — no cloud, no sync.

---

## 📱 App Tabs

| Tab | Screen |
|---|---|
| 📊 Dashboard | Balance card, pie chart, monthly trend, recent transactions |
| 📋 Transactions | Full list with search + filters; long-press to delete |
| ➕ Add | Quick add income/expense/transfer with category grid |
| 🎯 Budgets | Monthly budget tracking with progress bars |
| ⋯ More | Reports · Goals · Settings |

---

## ⚙️ Customization

### Change Default Currency

In `src/constants/theme.ts`, update the currency symbol. In `src/database/db.ts` under `initDatabase()`, change the `currency` setting default.

### Add Custom Categories

Edit the `CATEGORIES_EXPENSE` and `CATEGORIES_INCOME` arrays in `src/constants/theme.ts`.

### Change Theme Colors

Edit `Colors` object in `src/constants/theme.ts`. All screens reference these variables.

### Change Notification Time

In `src/utils/notifications.ts`, edit `scheduleDailyReminder(21, 0)` — first arg is hour (24h), second is minutes.

---

## 🔧 Key Dependencies

| Package | Purpose |
|---|---|
| `expo-sqlite` | Local SQLite database (offline storage) |
| `expo-notifications` | Budget alerts + daily reminders |
| `expo-file-system` + `expo-sharing` | CSV/JSON export & sharing |
| `react-native-chart-kit` | Pie charts, line charts, bar charts |
| `@react-navigation/native` | Stack + tab navigation |
| `expo-linear-gradient` | Gradient cards |
| `expo-haptics` | Success feedback on transaction save |
| `zustand` | Lightweight global state management |
| `date-fns` | Date formatting and calculations |

---

## 🛠️ Troubleshooting

**"Metro bundler not found"**
```bash
npx expo start --clear
```

**Android emulator not detected**
```bash
# Make sure emulator is running, then:
adb devices
npx expo start --android
```

**SQLite errors on first run**
```bash
# Clear app data on device, or:
npx expo start --clear
```

**Build fails with Gradle error**
```bash
cd android
./gradlew clean
cd ..
npx expo run:android
```

---

## 📄 License

MIT — free to use, modify, and distribute.

---

Built with ❤️ using React Native + Expo
